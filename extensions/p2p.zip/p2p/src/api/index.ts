export { apolloClient } from './graphql/client';
export * from './graphql/queries';
export * from './graphql/mutations';
export * from './mockData';

