export { i as default } from './index-COvqqES_.js';
//# sourceMappingURL=__federation_shared_react-dom-BN8Au471.js.map
