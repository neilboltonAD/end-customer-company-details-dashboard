import { importShared } from './__federation_fn_import-RtkuUH3Q.js';
import { j as jsxRuntimeExports } from './jsx-runtime-CyoIsdjr.js';

const {useSyncExternalStore} = await importShared('react');


function createStore(initialState) {
  let state = initialState;
  let initialized = false;
  const listeners = /* @__PURE__ */ new Set();
  return {
    getState() {
      return state;
    },
    updateState(value) {
      state = typeof value === "function" ? value(state) : value;
    },
    setState(value) {
      this.updateState(value);
      listeners.forEach((listener) => listener(state));
    },
    initialize(value) {
      if (!initialized) {
        state = value;
        initialized = true;
      }
    },
    subscribe(callback) {
      listeners.add(callback);
      return () => listeners.delete(callback);
    }
  };
}
function useStore(store) {
  return useSyncExternalStore(
    store.subscribe,
    () => store.getState(),
    () => store.getState()
  );
}

const {randomId} = await importShared('@mantine/hooks');

function getDistributedNotifications(data, defaultPosition, limit) {
  const queue = [];
  const notifications2 = [];
  const count = {};
  for (const item of data) {
    const position = item.position || defaultPosition;
    count[position] = count[position] || 0;
    count[position] += 1;
    if (count[position] <= limit) {
      notifications2.push(item);
    } else {
      queue.push(item);
    }
  }
  return { notifications: notifications2, queue };
}
const createNotificationsStore = () => createStore({
  notifications: [],
  queue: [],
  defaultPosition: "bottom-right",
  limit: 5
});
const notificationsStore = createNotificationsStore();
const useNotifications = (store = notificationsStore) => useStore(store);
function updateNotificationsState(store, update) {
  const state = store.getState();
  const notifications2 = update([...state.notifications, ...state.queue]);
  const updated = getDistributedNotifications(notifications2, state.defaultPosition, state.limit);
  store.setState({
    notifications: updated.notifications,
    queue: updated.queue,
    limit: state.limit,
    defaultPosition: state.defaultPosition
  });
}
function showNotification(notification, store = notificationsStore) {
  const id = notification.id || randomId();
  updateNotificationsState(store, (notifications2) => {
    if (notification.id && notifications2.some((n) => n.id === notification.id)) {
      return notifications2;
    }
    return [...notifications2, { ...notification, id }];
  });
  return id;
}
function hideNotification(id, store = notificationsStore) {
  updateNotificationsState(
    store,
    (notifications2) => notifications2.filter((notification) => {
      if (notification.id === id) {
        notification.onClose?.(notification);
        return false;
      }
      return true;
    })
  );
  return id;
}
function updateNotification(notification, store = notificationsStore) {
  updateNotificationsState(
    store,
    (notifications2) => notifications2.map((item) => {
      if (item.id === notification.id) {
        return { ...item, ...notification };
      }
      return item;
    })
  );
  return notification.id;
}
function cleanNotifications(store = notificationsStore) {
  updateNotificationsState(store, () => []);
}
function cleanNotificationsQueue(store = notificationsStore) {
  updateNotificationsState(
    store,
    (notifications2) => notifications2.slice(0, store.getState().limit)
  );
}
const notifications = {
  show: showNotification,
  hide: hideNotification,
  update: updateNotification,
  clean: cleanNotifications,
  cleanQueue: cleanNotificationsQueue,
  updateState: updateNotificationsState
};

const {createContext: createContext$1,useContext: useContext$1,useEffect: useEffect$1,useState: useState$5} = await importShared('react');

const defaultSettings = {
  enableNotifications: true,
  transferExpiryDays: 30
};
const demoContext = {
  user: {
    id: "demo-user-1",
    email: "neil.bolton@appdirect.com",
    firstName: "Neil",
    lastName: "Bolton",
    roles: ["MARKETPLACE_MANAGER"],
    permissions: [
      "company.read",
      "company.subscriptions.read",
      "company.subscriptions.write",
      "vendor.microsoft.read",
      "vendor.microsoft.write"
    ]
  },
  company: {
    id: "company-123",
    name: "demoresellercustomer3",
    externalId: "7c7cd39e-e239-43c5-b099-0888671761af",
    microsoftTenantId: "8e97f6e7-f67b-445f-9e85-3b2c4f7d8a9e",
    mpnId: "9876543"
  },
  marketplace: {
    id: "marketplace-1",
    name: "Demo Marketplace",
    baseUrl: "https://demo.appdirect.com",
    apiUrl: "https://demo.appdirect.com/api/graphql"
  },
  settings: defaultSettings,
  loading: false,
  error: null,
  sessionToken: "demo-session-token"
};
const loadingContext = {
  user: null,
  company: null,
  marketplace: null,
  settings: defaultSettings,
  loading: true,
  error: null,
  sessionToken: null
};
const ExtensionContext = createContext$1(demoContext);
function ExtensionProvider({ children }) {
  const [context, setContext] = useState$5(loadingContext);
  useEffect$1(() => {
    const isEmbedded = window.parent !== window;
    if (isEmbedded) {
      const handleMessage = (event) => {
        if (event.data?.type === "EXTENSION_CONTEXT") {
          const { user, company, marketplace, settings, sessionToken } = event.data.payload;
          setContext({
            user,
            company,
            marketplace,
            settings: { ...defaultSettings, ...settings },
            loading: false,
            error: null,
            sessionToken
          });
        }
        if (event.data?.type === "EXTENSION_ERROR") {
          setContext((prev) => ({
            ...prev,
            loading: false,
            error: new Error(event.data.payload.message)
          }));
        }
      };
      window.addEventListener("message", handleMessage);
      window.parent.postMessage({ type: "REQUEST_EXTENSION_CONTEXT" }, "*");
      const timeout = setTimeout(() => {
        if (context.loading) {
          console.log("[P2P Extension] No host context received, using demo mode");
          setContext(demoContext);
        }
      }, 2e3);
      return () => {
        window.removeEventListener("message", handleMessage);
        clearTimeout(timeout);
      };
    } else {
      console.log("[P2P Extension] Running in standalone demo mode");
      const timeout = setTimeout(() => {
        setContext(demoContext);
      }, 300);
      return () => clearTimeout(timeout);
    }
  }, [context.loading]);
  return /* @__PURE__ */ jsxRuntimeExports.jsx(ExtensionContext.Provider, { value: context, children });
}
function useExtension() {
  const context = useContext$1(ExtensionContext);
  if (!context) {
    throw new Error("useExtension must be used within ExtensionProvider");
  }
  return context;
}

const mockSubscriptions = [
  {
    id: "sub-1",
    microsoftSubscriptionId: "a1b2c3d4-e5f6-7890-abcd-111111111111",
    offerId: "CFQ7TTC0LH18",
    productName: "Microsoft 365 Business Premium",
    skuName: "Microsoft 365 Business Premium",
    quantity: 50,
    billingCycle: "Monthly",
    termDuration: "P1Y",
    monthlyValue: 1100,
    status: "Active",
    isTransferable: true
  },
  {
    id: "sub-2",
    microsoftSubscriptionId: "a1b2c3d4-e5f6-7890-abcd-222222222222",
    offerId: "CFQ7TTC0LFLX",
    productName: "Microsoft 365 E3",
    skuName: "Microsoft 365 E3",
    quantity: 30,
    billingCycle: "Annual",
    termDuration: "P1Y",
    monthlyValue: 1080,
    status: "Active",
    isTransferable: true
  },
  {
    id: "sub-3",
    microsoftSubscriptionId: "a1b2c3d4-e5f6-7890-abcd-333333333333",
    offerId: "CFQ7TTC0LFLZ",
    productName: "Microsoft 365 E5",
    skuName: "Microsoft 365 E5",
    quantity: 10,
    billingCycle: "Monthly",
    termDuration: "P3Y",
    monthlyValue: 570,
    status: "Active",
    isTransferable: true
  },
  {
    id: "sub-4",
    microsoftSubscriptionId: "a1b2c3d4-e5f6-7890-abcd-444444444444",
    offerId: "CFQ7TTC0RM8K",
    productName: "Microsoft Teams Rooms Pro",
    skuName: "Teams Rooms Pro",
    quantity: 25,
    billingCycle: "Monthly",
    termDuration: "P1Y",
    monthlyValue: 500,
    status: "Active",
    isTransferable: true
  },
  {
    id: "sub-5",
    microsoftSubscriptionId: "a1b2c3d4-e5f6-7890-abcd-555555555555",
    offerId: "CFQ7TTC0LHXM",
    productName: "Microsoft Defender for Business",
    skuName: "Defender for Business",
    quantity: 50,
    billingCycle: "Monthly",
    termDuration: "P1Y",
    monthlyValue: 250,
    status: "Active",
    isTransferable: true
  },
  {
    id: "sub-6",
    microsoftSubscriptionId: "a1b2c3d4-e5f6-7890-abcd-666666666666",
    offerId: "CFQ7TTC0NXVL",
    productName: "Power BI Pro",
    skuName: "Power BI Pro",
    quantity: 15,
    billingCycle: "Monthly",
    termDuration: "P1Y",
    monthlyValue: 150,
    status: "Active",
    isTransferable: true
  },
  {
    id: "sub-7",
    microsoftSubscriptionId: "a1b2c3d4-e5f6-7890-abcd-777777777777",
    offerId: "CFQ7TTC0HDB1",
    productName: "Azure Reserved VM Instances",
    skuName: "Standard_D4s_v3 (3 Year)",
    quantity: 2,
    billingCycle: "Annual",
    termDuration: "P3Y",
    monthlyValue: 890,
    status: "Active",
    isTransferable: false,
    ineligibilityReason: "Azure Reserved Instances cannot be transferred"
  }
];
const now = /* @__PURE__ */ new Date();
const daysFromNow = (days) => {
  const date = new Date(now);
  date.setDate(date.getDate() + days);
  return date.toISOString();
};
const daysAgo = (days) => daysFromNow(-days);
const partners = {
  contoso: {
    id: "partner-contoso",
    name: "Contoso Partner Ltd",
    tenantId: "a1b2c3d4-e5f6-7890-abcd-ef1234567890",
    mpnId: "1234567"
  },
  fabrikam: {
    id: "partner-fabrikam",
    name: "Fabrikam Inc",
    tenantId: "b2c3d4e5-f6a7-8901-bcde-f23456789012",
    mpnId: "2345678"
  },
  northwind: {
    id: "partner-northwind",
    name: "Northwind Traders",
    tenantId: "c3d4e5f6-a7b8-9012-cdef-345678901234",
    mpnId: "3456789"
  },
  acme: {
    id: "partner-acme",
    name: "Acme Corp",
    tenantId: "d4e5f6a7-b8c9-0123-def0-456789012345",
    mpnId: "4567890"
  },
  techstart: {
    id: "partner-techstart",
    name: "TechStart LLC",
    tenantId: "e5f6a7b8-c9d0-1234-ef01-567890123456",
    mpnId: "5678901"
  },
  cloudfirst: {
    id: "partner-cloudfirst",
    name: "CloudFirst Partners",
    tenantId: "f6a7b8c9-d0e1-2345-f012-678901234567",
    mpnId: "6789012"
  },
  demoReseller: {
    id: "partner-demo",
    name: "Demo Reseller",
    tenantId: "408f194e-7263-4a16-8b97-5d4f8a9e3b7c",
    mpnId: "9876543"
  }
};
const mockTransferRequests = [
  // Incoming pending transfers - these need action
  {
    id: "transfer-in-1",
    direction: "Incoming",
    status: "Pending",
    sourcePartner: partners.contoso,
    targetPartner: partners.demoReseller,
    customerTenantId: "8e97f6e7-f67b-445f-9e85-3b2c4f7d8a9e",
    customerName: "demoresellercustomer3",
    lineItems: [
      {
        id: "li-1",
        subscriptionId: "ext-sub-001",
        offerId: "CFQ7TTC0LH18",
        productName: "Microsoft 365 Business Premium",
        skuName: "Microsoft 365 Business Premium",
        quantity: 25,
        billingCycle: "Monthly",
        termDuration: "P1Y",
        monthlyValue: 550,
        status: "Pending"
      },
      {
        id: "li-2",
        subscriptionId: "ext-sub-002",
        offerId: "CFQ7TTC0LFLX",
        productName: "Microsoft 365 E3",
        skuName: "Microsoft 365 E3",
        quantity: 15,
        billingCycle: "Annual",
        termDuration: "P1Y",
        monthlyValue: 540,
        status: "Pending"
      }
    ],
    totalMonthlyValue: 1090,
    createdDate: daysAgo(2),
    lastModifiedDate: daysAgo(2),
    expirationDate: daysFromNow(28)
  },
  {
    id: "transfer-in-2",
    direction: "Incoming",
    status: "Pending",
    sourcePartner: partners.fabrikam,
    targetPartner: partners.demoReseller,
    customerTenantId: "8e97f6e7-f67b-445f-9e85-3b2c4f7d8a9e",
    customerName: "demoresellercustomer3",
    lineItems: [
      {
        id: "li-3",
        subscriptionId: "ext-sub-003",
        offerId: "CFQ7TTC0LFLZ",
        productName: "Microsoft 365 E5",
        skuName: "Microsoft 365 E5",
        quantity: 10,
        billingCycle: "Monthly",
        termDuration: "P1Y",
        monthlyValue: 600,
        status: "Pending"
      }
    ],
    totalMonthlyValue: 600,
    createdDate: daysAgo(5),
    lastModifiedDate: daysAgo(5),
    expirationDate: daysFromNow(5)
    // URGENT - expires soon!
  },
  {
    id: "transfer-in-3",
    direction: "Incoming",
    status: "Pending",
    sourcePartner: partners.northwind,
    targetPartner: partners.demoReseller,
    customerTenantId: "8e97f6e7-f67b-445f-9e85-3b2c4f7d8a9e",
    customerName: "demoresellercustomer3",
    lineItems: [
      {
        id: "li-4",
        subscriptionId: "ext-sub-004",
        offerId: "CFQ7TTC0RM8K",
        productName: "Microsoft Teams Rooms Pro",
        skuName: "Teams Rooms Pro",
        quantity: 10,
        billingCycle: "Monthly",
        termDuration: "P1Y",
        monthlyValue: 500,
        status: "Pending"
      },
      {
        id: "li-5",
        subscriptionId: "ext-sub-005",
        offerId: "CFQ7TTC0NXVL",
        productName: "Power BI Pro",
        skuName: "Power BI Pro",
        quantity: 20,
        billingCycle: "Monthly",
        termDuration: "P1Y",
        monthlyValue: 200,
        status: "Pending"
      }
    ],
    totalMonthlyValue: 700,
    createdDate: daysAgo(0),
    lastModifiedDate: daysAgo(0),
    expirationDate: daysFromNow(30)
  },
  // Outgoing pending transfer - awaiting partner response
  {
    id: "transfer-out-1",
    direction: "Outgoing",
    status: "Pending",
    sourcePartner: partners.demoReseller,
    targetPartner: partners.acme,
    customerTenantId: "8e97f6e7-f67b-445f-9e85-3b2c4f7d8a9e",
    customerName: "demoresellercustomer3",
    lineItems: [
      {
        id: "li-6",
        subscriptionId: "sub-5",
        offerId: "CFQ7TTC0LHXM",
        productName: "Microsoft Defender for Business",
        skuName: "Defender for Business",
        quantity: 20,
        billingCycle: "Monthly",
        termDuration: "P1Y",
        monthlyValue: 220,
        status: "Pending"
      }
    ],
    totalMonthlyValue: 220,
    createdDate: daysAgo(3),
    lastModifiedDate: daysAgo(3),
    expirationDate: daysFromNow(27)
  },
  // Completed transfer - success story
  {
    id: "transfer-completed-1",
    direction: "Incoming",
    status: "Completed",
    sourcePartner: partners.techstart,
    targetPartner: partners.demoReseller,
    customerTenantId: "8e97f6e7-f67b-445f-9e85-3b2c4f7d8a9e",
    customerName: "demoresellercustomer3",
    lineItems: [
      {
        id: "li-7",
        subscriptionId: "completed-sub-001",
        offerId: "CFQ7TTC0LFLX",
        productName: "Microsoft 365 E3",
        skuName: "Microsoft 365 E3",
        quantity: 40,
        billingCycle: "Annual",
        termDuration: "P1Y",
        monthlyValue: 1440,
        status: "Transferred"
      }
    ],
    totalMonthlyValue: 1440,
    createdDate: daysAgo(15),
    lastModifiedDate: daysAgo(10),
    expirationDate: daysAgo(0),
    completedDate: daysAgo(10)
  },
  {
    id: "transfer-completed-2",
    direction: "Outgoing",
    status: "Completed",
    sourcePartner: partners.demoReseller,
    targetPartner: partners.fabrikam,
    customerTenantId: "different-customer-123",
    customerName: "Woodgrove Bank",
    lineItems: [
      {
        id: "li-8",
        subscriptionId: "completed-sub-002",
        offerId: "CFQ7TTC0NXVL",
        productName: "Power BI Pro",
        skuName: "Power BI Pro",
        quantity: 50,
        billingCycle: "Monthly",
        termDuration: "P1Y",
        monthlyValue: 500,
        status: "Transferred"
      }
    ],
    totalMonthlyValue: 500,
    createdDate: daysAgo(45),
    lastModifiedDate: daysAgo(40),
    expirationDate: daysAgo(15),
    completedDate: daysAgo(40)
  },
  // Rejected transfer - shows rejection flow
  {
    id: "transfer-rejected-1",
    direction: "Outgoing",
    status: "Rejected",
    sourcePartner: partners.demoReseller,
    targetPartner: partners.cloudfirst,
    customerTenantId: "8e97f6e7-f67b-445f-9e85-3b2c4f7d8a9e",
    customerName: "demoresellercustomer3",
    lineItems: [
      {
        id: "li-9",
        subscriptionId: "rejected-sub-001",
        offerId: "CFQ7TTC0NXVL",
        productName: "Power BI Pro",
        skuName: "Power BI Pro",
        quantity: 20,
        billingCycle: "Monthly",
        termDuration: "P1Y",
        monthlyValue: 440,
        status: "Failed"
      }
    ],
    totalMonthlyValue: 440,
    createdDate: daysAgo(25),
    lastModifiedDate: daysAgo(20),
    expirationDate: daysAgo(5),
    rejectionReason: "Customer relationship not established with target partner"
  }
];

const {createContext,useContext,useState: useState$4,useCallback: useCallback$2} = await importShared('react');
const P2PContext = createContext(null);
function P2PProvider({ children }) {
  const [transfers, setTransfers] = useState$4(mockTransferRequests);
  const [subscriptions, setSubscriptions] = useState$4(mockSubscriptions);
  const [isLoadingTransfers, setIsLoadingTransfers] = useState$4(false);
  const [isLoadingSubscriptions, setIsLoadingSubscriptions] = useState$4(false);
  const [isSubmitting, setIsSubmitting] = useState$4(false);
  const [error, setError] = useState$4(null);
  const incomingPending = transfers.filter((t) => t.direction === "Incoming" && t.status === "Pending");
  const outgoingPending = transfers.filter((t) => t.direction === "Outgoing" && t.status === "Pending");
  const completedTransfers = transfers.filter((t) => t.status === "Completed");
  const failedTransfers = transfers.filter(
    (t) => t.status === "Failed" || t.status === "Rejected" || t.status === "Cancelled"
  );
  const summary = {
    incomingPending: incomingPending.length,
    outgoingPending: outgoingPending.length,
    completedLast90Days: completedTransfers.length,
    failedLast90Days: failedTransfers.length
  };
  const refreshTransfers = useCallback$2(async () => {
    setIsLoadingTransfers(true);
    setError(null);
    try {
      await new Promise((resolve) => setTimeout(resolve, 500));
    } catch (err) {
      setError(err instanceof Error ? err : new Error("Failed to load transfers"));
    } finally {
      setIsLoadingTransfers(false);
    }
  }, []);
  const refreshSubscriptions = useCallback$2(async () => {
    setIsLoadingSubscriptions(true);
    setError(null);
    try {
      await new Promise((resolve) => setTimeout(resolve, 300));
    } catch (err) {
      setError(err instanceof Error ? err : new Error("Failed to load subscriptions"));
    } finally {
      setIsLoadingSubscriptions(false);
    }
  }, []);
  const createTransfer = useCallback$2(async (input) => {
    setIsSubmitting(true);
    setError(null);
    try {
      await new Promise((resolve) => setTimeout(resolve, 800));
      const selectedSubs = subscriptions.filter((s) => input.subscriptionIds.includes(s.id));
      const totalValue = selectedSubs.reduce((sum, s) => sum + s.monthlyValue, 0);
      const newTransfer = {
        id: `transfer-${Date.now()}`,
        direction: "Outgoing",
        status: "Pending",
        sourcePartner: {
          id: "partner-demo",
          name: "Demo Reseller",
          tenantId: "408f194e-7263-4a16-8b97-5d4f8a9e3b7c",
          mpnId: "9876543"
        },
        targetPartner: {
          id: "partner-target",
          name: "Target Partner",
          tenantId: input.targetPartnerTenantId,
          mpnId: input.targetPartnerMpnId
        },
        customerTenantId: "8e97f6e7-f67b-445f-9e85-3b2c4f7d8a9e",
        customerName: "demoresellercustomer3",
        lineItems: selectedSubs.map((sub, i) => ({
          id: `li-new-${i}`,
          subscriptionId: sub.id,
          offerId: sub.offerId,
          productName: sub.productName,
          skuName: sub.skuName,
          quantity: sub.quantity,
          billingCycle: sub.billingCycle,
          termDuration: sub.termDuration,
          monthlyValue: sub.monthlyValue,
          status: "Pending"
        })),
        totalMonthlyValue: totalValue,
        createdDate: (/* @__PURE__ */ new Date()).toISOString(),
        lastModifiedDate: (/* @__PURE__ */ new Date()).toISOString(),
        expirationDate: new Date(Date.now() + 30 * 24 * 60 * 60 * 1e3).toISOString()
      };
      setTransfers((prev) => [...prev, newTransfer]);
      return newTransfer;
    } catch (err) {
      const error2 = err instanceof Error ? err : new Error("Failed to create transfer");
      setError(error2);
      throw error2;
    } finally {
      setIsSubmitting(false);
    }
  }, [subscriptions]);
  const acceptTransfer = useCallback$2(async (transferId) => {
    setIsSubmitting(true);
    setError(null);
    try {
      await new Promise((resolve) => setTimeout(resolve, 600));
      let updatedTransfer;
      setTransfers((prev) => prev.map((t) => {
        if (t.id === transferId) {
          updatedTransfer = {
            ...t,
            status: "InProgress",
            lastModifiedDate: (/* @__PURE__ */ new Date()).toISOString()
          };
          return updatedTransfer;
        }
        return t;
      }));
      setTimeout(() => {
        setTransfers((prev) => prev.map(
          (t) => t.id === transferId ? {
            ...t,
            status: "Completed",
            completedDate: (/* @__PURE__ */ new Date()).toISOString(),
            lastModifiedDate: (/* @__PURE__ */ new Date()).toISOString()
          } : t
        ));
      }, 2e3);
      return updatedTransfer || transfers.find((t) => t.id === transferId);
    } catch (err) {
      const error2 = err instanceof Error ? err : new Error("Failed to accept transfer");
      setError(error2);
      throw error2;
    } finally {
      setIsSubmitting(false);
    }
  }, [transfers]);
  const rejectTransfer = useCallback$2(async (transferId, input) => {
    setIsSubmitting(true);
    setError(null);
    try {
      await new Promise((resolve) => setTimeout(resolve, 500));
      let updatedTransfer;
      setTransfers((prev) => prev.map((t) => {
        if (t.id === transferId) {
          updatedTransfer = {
            ...t,
            status: "Rejected",
            rejectionReason: input.reason,
            lastModifiedDate: (/* @__PURE__ */ new Date()).toISOString()
          };
          return updatedTransfer;
        }
        return t;
      }));
      return updatedTransfer || transfers.find((t) => t.id === transferId);
    } catch (err) {
      const error2 = err instanceof Error ? err : new Error("Failed to reject transfer");
      setError(error2);
      throw error2;
    } finally {
      setIsSubmitting(false);
    }
  }, [transfers]);
  const cancelTransfer = useCallback$2(async (transferId) => {
    setIsSubmitting(true);
    setError(null);
    try {
      await new Promise((resolve) => setTimeout(resolve, 400));
      let updatedTransfer;
      setTransfers((prev) => prev.map((t) => {
        if (t.id === transferId) {
          updatedTransfer = {
            ...t,
            status: "Cancelled",
            lastModifiedDate: (/* @__PURE__ */ new Date()).toISOString()
          };
          return updatedTransfer;
        }
        return t;
      }));
      return updatedTransfer || transfers.find((t) => t.id === transferId);
    } catch (err) {
      const error2 = err instanceof Error ? err : new Error("Failed to cancel transfer");
      setError(error2);
      throw error2;
    } finally {
      setIsSubmitting(false);
    }
  }, [transfers]);
  const value = {
    transfers,
    subscriptions,
    summary,
    isLoadingTransfers,
    isLoadingSubscriptions,
    isSubmitting,
    error,
    refreshTransfers,
    refreshSubscriptions,
    createTransfer,
    acceptTransfer,
    rejectTransfer,
    cancelTransfer,
    incomingPending,
    outgoingPending,
    completedTransfers,
    failedTransfers
  };
  return /* @__PURE__ */ jsxRuntimeExports.jsx(P2PContext.Provider, { value, children });
}
function useP2P() {
  const context = useContext(P2PContext);
  if (!context) {
    throw new Error("useP2P must be used within P2PProvider");
  }
  return context;
}

/**
 * @license lucide-react v0.312.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */

var defaultAttributes = {
  xmlns: "http://www.w3.org/2000/svg",
  width: 24,
  height: 24,
  viewBox: "0 0 24 24",
  fill: "none",
  stroke: "currentColor",
  strokeWidth: 2,
  strokeLinecap: "round",
  strokeLinejoin: "round"
};

/**
 * @license lucide-react v0.312.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */

const {forwardRef,createElement} = await importShared('react');

const toKebabCase = (string) => string.replace(/([a-z0-9])([A-Z])/g, "$1-$2").toLowerCase().trim();
const createLucideIcon = (iconName, iconNode) => {
  const Component = forwardRef(
    ({ color = "currentColor", size = 24, strokeWidth = 2, absoluteStrokeWidth, className = "", children, ...rest }, ref) => {
      return createElement(
        "svg",
        {
          ref,
          ...defaultAttributes,
          width: size,
          height: size,
          stroke: color,
          strokeWidth: absoluteStrokeWidth ? Number(strokeWidth) * 24 / Number(size) : strokeWidth,
          className: ["lucide", `lucide-${toKebabCase(iconName)}`, className].join(" "),
          ...rest
        },
        [
          ...iconNode.map(([tag, attrs]) => createElement(tag, attrs)),
          ...Array.isArray(children) ? children : [children]
        ]
      );
    }
  );
  Component.displayName = `${iconName}`;
  return Component;
};

/**
 * @license lucide-react v0.312.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */


const AlertCircle = createLucideIcon("AlertCircle", [
  ["circle", { cx: "12", cy: "12", r: "10", key: "1mglay" }],
  ["line", { x1: "12", x2: "12", y1: "8", y2: "12", key: "1pkeuh" }],
  ["line", { x1: "12", x2: "12.01", y1: "16", y2: "16", key: "4dfq90" }]
]);

/**
 * @license lucide-react v0.312.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */


const AlertTriangle = createLucideIcon("AlertTriangle", [
  [
    "path",
    {
      d: "m21.73 18-8-14a2 2 0 0 0-3.48 0l-8 14A2 2 0 0 0 4 21h16a2 2 0 0 0 1.73-3Z",
      key: "c3ski4"
    }
  ],
  ["path", { d: "M12 9v4", key: "juzpu7" }],
  ["path", { d: "M12 17h.01", key: "p32p05" }]
]);

/**
 * @license lucide-react v0.312.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */


const ArrowDownLeft = createLucideIcon("ArrowDownLeft", [
  ["path", { d: "M17 7 7 17", key: "15tmo1" }],
  ["path", { d: "M17 17H7V7", key: "1org7z" }]
]);

/**
 * @license lucide-react v0.312.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */


const ArrowUpRight = createLucideIcon("ArrowUpRight", [
  ["path", { d: "M7 7h10v10", key: "1tivn9" }],
  ["path", { d: "M7 17 17 7", key: "1vkiza" }]
]);

/**
 * @license lucide-react v0.312.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */


const Building2 = createLucideIcon("Building2", [
  ["path", { d: "M6 22V4a2 2 0 0 1 2-2h8a2 2 0 0 1 2 2v18Z", key: "1b4qmf" }],
  ["path", { d: "M6 12H4a2 2 0 0 0-2 2v6a2 2 0 0 0 2 2h2", key: "i71pzd" }],
  ["path", { d: "M18 9h2a2 2 0 0 1 2 2v9a2 2 0 0 1-2 2h-2", key: "10jefs" }],
  ["path", { d: "M10 6h4", key: "1itunk" }],
  ["path", { d: "M10 10h4", key: "tcdvrf" }],
  ["path", { d: "M10 14h4", key: "kelpxr" }],
  ["path", { d: "M10 18h4", key: "1ulq68" }]
]);

/**
 * @license lucide-react v0.312.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */


const CheckCircle = createLucideIcon("CheckCircle", [
  ["path", { d: "M22 11.08V12a10 10 0 1 1-5.93-9.14", key: "g774vq" }],
  ["path", { d: "m9 11 3 3L22 4", key: "1pflzl" }]
]);

/**
 * @license lucide-react v0.312.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */


const Check = createLucideIcon("Check", [["path", { d: "M20 6 9 17l-5-5", key: "1gmf2c" }]]);

/**
 * @license lucide-react v0.312.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */


const Clock = createLucideIcon("Clock", [
  ["circle", { cx: "12", cy: "12", r: "10", key: "1mglay" }],
  ["polyline", { points: "12 6 12 12 16 14", key: "68esgv" }]
]);

/**
 * @license lucide-react v0.312.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */


const Eye = createLucideIcon("Eye", [
  ["path", { d: "M2 12s3-7 10-7 10 7 10 7-3 7-10 7-10-7-10-7Z", key: "rwhkz3" }],
  ["circle", { cx: "12", cy: "12", r: "3", key: "1v7zrd" }]
]);

/**
 * @license lucide-react v0.312.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */


const FileCheck = createLucideIcon("FileCheck", [
  ["path", { d: "M15 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7Z", key: "1rqfz7" }],
  ["path", { d: "M14 2v4a2 2 0 0 0 2 2h4", key: "tnqrlb" }],
  ["path", { d: "m9 15 2 2 4-4", key: "1grp1n" }]
]);

/**
 * @license lucide-react v0.312.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */


const Info = createLucideIcon("Info", [
  ["circle", { cx: "12", cy: "12", r: "10", key: "1mglay" }],
  ["path", { d: "M12 16v-4", key: "1dtifu" }],
  ["path", { d: "M12 8h.01", key: "e9boi3" }]
]);

/**
 * @license lucide-react v0.312.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */


const Plus = createLucideIcon("Plus", [
  ["path", { d: "M5 12h14", key: "1ays0h" }],
  ["path", { d: "M12 5v14", key: "s699le" }]
]);

/**
 * @license lucide-react v0.312.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */


const RefreshCw = createLucideIcon("RefreshCw", [
  ["path", { d: "M3 12a9 9 0 0 1 9-9 9.75 9.75 0 0 1 6.74 2.74L21 8", key: "v9h5vc" }],
  ["path", { d: "M21 3v5h-5", key: "1q7to0" }],
  ["path", { d: "M21 12a9 9 0 0 1-9 9 9.75 9.75 0 0 1-6.74-2.74L3 16", key: "3uifl3" }],
  ["path", { d: "M8 16H3v5", key: "1cv678" }]
]);

/**
 * @license lucide-react v0.312.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */


const Search = createLucideIcon("Search", [
  ["circle", { cx: "11", cy: "11", r: "8", key: "4ej97u" }],
  ["path", { d: "m21 21-4.3-4.3", key: "1qie3q" }]
]);

/**
 * @license lucide-react v0.312.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */


const Send = createLucideIcon("Send", [
  ["path", { d: "m22 2-7 20-4-9-9-4Z", key: "1q3vgg" }],
  ["path", { d: "M22 2 11 13", key: "nzbqef" }]
]);

/**
 * @license lucide-react v0.312.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */


const Sparkles = createLucideIcon("Sparkles", [
  [
    "path",
    {
      d: "m12 3-1.912 5.813a2 2 0 0 1-1.275 1.275L3 12l5.813 1.912a2 2 0 0 1 1.275 1.275L12 21l1.912-5.813a2 2 0 0 1 1.275-1.275L21 12l-5.813-1.912a2 2 0 0 1-1.275-1.275L12 3Z",
      key: "17u4zn"
    }
  ],
  ["path", { d: "M5 3v4", key: "bklmnn" }],
  ["path", { d: "M19 17v4", key: "iiml17" }],
  ["path", { d: "M3 5h4", key: "nem4j1" }],
  ["path", { d: "M17 19h4", key: "lbex7p" }]
]);

/**
 * @license lucide-react v0.312.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */


const User = createLucideIcon("User", [
  ["path", { d: "M19 21v-2a4 4 0 0 0-4-4H9a4 4 0 0 0-4 4v2", key: "975kel" }],
  ["circle", { cx: "12", cy: "7", r: "4", key: "17ys0d" }]
]);

/**
 * @license lucide-react v0.312.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */


const XCircle = createLucideIcon("XCircle", [
  ["circle", { cx: "12", cy: "12", r: "10", key: "1mglay" }],
  ["path", { d: "m15 9-6 6", key: "1uzhvr" }],
  ["path", { d: "m9 9 6 6", key: "z0biqf" }]
]);

/**
 * @license lucide-react v0.312.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */


const X = createLucideIcon("X", [
  ["path", { d: "M18 6 6 18", key: "1bl5f8" }],
  ["path", { d: "m6 6 12 12", key: "d8bk6v" }]
]);

function useExtensionContext() {
  const context = useExtension();
  const hasPermission = (permission) => {
    if (!context.user) return false;
    return context.user.permissions.includes(permission);
  };
  const isMarketplaceManager = context.user?.roles.includes("MARKETPLACE_MANAGER") ?? false;
  return {
    ...context,
    hasPermission,
    isMarketplaceManager
  };
}

function useTransfers() {
  const {
    transfers,
    incomingPending,
    outgoingPending,
    completedTransfers,
    failedTransfers,
    summary,
    isLoadingTransfers,
    isSubmitting,
    error,
    refreshTransfers,
    createTransfer,
    acceptTransfer,
    rejectTransfer,
    cancelTransfer
  } = useP2P();
  const reject = async (transferId, reason) => {
    return rejectTransfer(transferId, { reason });
  };
  return {
    transfers,
    incomingPending,
    outgoingPending,
    completedTransfers,
    failedTransfers,
    summary,
    loading: isLoadingTransfers,
    submitting: isSubmitting,
    error,
    refresh: refreshTransfers,
    create: createTransfer,
    accept: acceptTransfer,
    reject,
    cancel: cancelTransfer
  };
}

function formatCurrency(amount) {
  return new Intl.NumberFormat("en-US", {
    style: "currency",
    currency: "USD",
    minimumFractionDigits: 0,
    maximumFractionDigits: 0
  }).format(amount);
}
function formatDate(dateString) {
  return new Date(dateString).toLocaleDateString("en-US", {
    month: "short",
    day: "numeric",
    year: "numeric"
  });
}
function formatDateTime(dateString) {
  return new Date(dateString).toLocaleString("en-US", {
    month: "short",
    day: "numeric",
    year: "numeric",
    hour: "numeric",
    minute: "2-digit"
  });
}
function getDaysUntilExpiration(expirationDate) {
  const now = /* @__PURE__ */ new Date();
  const expiry = new Date(expirationDate);
  const diffTime = expiry.getTime() - now.getTime();
  return Math.ceil(diffTime / (1e3 * 60 * 60 * 24));
}
function formatTermDuration(term) {
  switch (term) {
    case "P1M":
      return "Monthly";
    case "P1Y":
      return "Annual";
    case "P3Y":
      return "Triennial";
    default:
      return term;
  }
}

const TRANSFER_STATUS_COLORS = {
  Pending: "yellow",
  InProgress: "blue",
  Completed: "green",
  Failed: "red",
  Rejected: "gray",
  Cancelled: "gray",
  Expired: "orange"
};
const REJECTION_REASONS = [
  { value: "no_relationship", label: "Customer relationship not established" },
  { value: "duplicate", label: "Duplicate transfer request" },
  { value: "incorrect_subscriptions", label: "Incorrect subscriptions included" },
  { value: "business_decision", label: "Business decision" },
  { value: "other", label: "Other" }
];

const {Badge: Badge$6} = await importShared('@mantine/core');
function TransferStatusBadge({ status, size = "sm" }) {
  const color = TRANSFER_STATUS_COLORS[status];
  const labels = {
    Pending: "Pending",
    InProgress: "Processing",
    Completed: "Completed",
    Failed: "Failed",
    Rejected: "Rejected",
    Cancelled: "Cancelled",
    Expired: "Expired"
  };
  return /* @__PURE__ */ jsxRuntimeExports.jsx(Badge$6, { color, size, variant: "light", children: labels[status] });
}

const {Center: Center$3,Loader: Loader$3,Text: Text$7,Stack: Stack$5} = await importShared('@mantine/core');

function LoadingState({ message = "Loading..." }) {
  return /* @__PURE__ */ jsxRuntimeExports.jsx(Center$3, { py: "xl", children: /* @__PURE__ */ jsxRuntimeExports.jsxs(Stack$5, { align: "center", gap: "sm", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx(Loader$3, { size: "lg" }),
    /* @__PURE__ */ jsxRuntimeExports.jsx(Text$7, { size: "sm", c: "dimmed", children: message })
  ] }) });
}

const {Alert: Alert$4,Group: Group$6,Text: Text$6,Badge: Badge$5} = await importShared('@mantine/core');
function DemoBanner() {
  return /* @__PURE__ */ jsxRuntimeExports.jsx(
    Alert$4,
    {
      color: "grape",
      variant: "light",
      mb: "md",
      icon: /* @__PURE__ */ jsxRuntimeExports.jsx(Sparkles, { size: 16 }),
      styles: {
        root: {
          borderLeft: "4px solid var(--mantine-color-grape-6)"
        }
      },
      children: /* @__PURE__ */ jsxRuntimeExports.jsxs(Group$6, { justify: "space-between", align: "center", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs(Text$6, { size: "sm", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("strong", { children: "Demo Mode" }),
          " — This extension is running with simulated data for stakeholder review."
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(Badge$5, { color: "grape", variant: "filled", size: "sm", children: "v1.0.0" })
      ] })
    }
  );
}

const UUID_REGEX = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
function isValidTenantId(tenantId) {
  return UUID_REGEX.test(tenantId.trim());
}
function isValidMpnId(mpnId) {
  return /^\d{5,10}$/.test(mpnId.trim());
}
function validateCreateTransferInput(input) {
  const errors = [];
  if (!input.targetPartnerTenantId) {
    errors.push("Target Partner Tenant ID is required");
  } else if (!isValidTenantId(input.targetPartnerTenantId)) {
    errors.push("Target Partner Tenant ID must be a valid GUID");
  }
  if (input.targetPartnerMpnId && !isValidMpnId(input.targetPartnerMpnId)) {
    errors.push("MPN ID must be a valid numeric identifier");
  }
  if (!input.subscriptionIds || input.subscriptionIds.length === 0) {
    errors.push("At least one subscription must be selected");
  }
  return {
    valid: errors.length === 0,
    errors
  };
}

const mockSearchableSubscriptions = [
  // demoresellercustomer3's subscriptions
  {
    id: "sub-1",
    microsoftSubscriptionId: "a1b2c3d4-e5f6-7890-abcd-111111111111",
    offerId: "CFQ7TTC0LH18",
    productName: "Microsoft 365 Business Premium",
    skuName: "Microsoft 365 Business Premium",
    quantity: 50,
    billingCycle: "Monthly",
    termDuration: "P1Y",
    monthlyValue: 1100,
    status: "Active",
    isTransferable: true,
    customerName: "demoresellercustomer3",
    customerId: "cust-001"
  },
  {
    id: "sub-2",
    microsoftSubscriptionId: "a1b2c3d4-e5f6-7890-abcd-222222222222",
    offerId: "CFQ7TTC0LFLX",
    productName: "Microsoft 365 E3",
    skuName: "Microsoft 365 E3",
    quantity: 30,
    billingCycle: "Annual",
    termDuration: "P1Y",
    monthlyValue: 1080,
    status: "Active",
    isTransferable: true,
    customerName: "demoresellercustomer3",
    customerId: "cust-001"
  },
  {
    id: "sub-3",
    microsoftSubscriptionId: "a1b2c3d4-e5f6-7890-abcd-333333333333",
    offerId: "CFQ7TTC0LFLZ",
    productName: "Microsoft 365 E5",
    skuName: "Microsoft 365 E5",
    quantity: 10,
    billingCycle: "Monthly",
    termDuration: "P3Y",
    monthlyValue: 570,
    status: "Active",
    isTransferable: true,
    customerName: "demoresellercustomer3",
    customerId: "cust-001"
  },
  // Woodgrove Bank subscriptions
  {
    id: "sub-wg-1",
    microsoftSubscriptionId: "b2c3d4e5-f6a7-8901-bcde-111111111111",
    offerId: "CFQ7TTC0LFLX",
    productName: "Microsoft 365 E3",
    skuName: "Microsoft 365 E3",
    quantity: 150,
    billingCycle: "Annual",
    termDuration: "P1Y",
    monthlyValue: 5400,
    status: "Active",
    isTransferable: true,
    customerName: "Woodgrove Bank",
    customerId: "cust-002"
  },
  {
    id: "sub-wg-2",
    microsoftSubscriptionId: "b2c3d4e5-f6a7-8901-bcde-222222222222",
    offerId: "CFQ7TTC0NXVL",
    productName: "Power BI Pro",
    skuName: "Power BI Pro",
    quantity: 75,
    billingCycle: "Monthly",
    termDuration: "P1Y",
    monthlyValue: 750,
    status: "Active",
    isTransferable: true,
    customerName: "Woodgrove Bank",
    customerId: "cust-002"
  },
  {
    id: "sub-wg-3",
    microsoftSubscriptionId: "b2c3d4e5-f6a7-8901-bcde-333333333333",
    offerId: "CFQ7TTC0HDB1",
    productName: "Azure Reserved VM Instances",
    skuName: "Standard_D4s_v3 (3 Year)",
    quantity: 5,
    billingCycle: "Annual",
    termDuration: "P3Y",
    monthlyValue: 2225,
    status: "Active",
    isTransferable: false,
    ineligibilityReason: "Azure Reserved Instances cannot be transferred",
    customerName: "Woodgrove Bank",
    customerId: "cust-002"
  },
  // Contoso Ltd subscriptions
  {
    id: "sub-co-1",
    microsoftSubscriptionId: "c3d4e5f6-a7b8-9012-cdef-111111111111",
    offerId: "CFQ7TTC0LH18",
    productName: "Microsoft 365 Business Premium",
    skuName: "Microsoft 365 Business Premium",
    quantity: 200,
    billingCycle: "Monthly",
    termDuration: "P1Y",
    monthlyValue: 4400,
    status: "Active",
    isTransferable: true,
    customerName: "Contoso Ltd",
    customerId: "cust-003"
  },
  {
    id: "sub-co-2",
    microsoftSubscriptionId: "c3d4e5f6-a7b8-9012-cdef-222222222222",
    offerId: "CFQ7TTC0RM8K",
    productName: "Microsoft Teams Rooms Pro",
    skuName: "Teams Rooms Pro",
    quantity: 50,
    billingCycle: "Monthly",
    termDuration: "P1Y",
    monthlyValue: 1e3,
    status: "Active",
    isTransferable: true,
    customerName: "Contoso Ltd",
    customerId: "cust-003"
  },
  // Fabrikam Inc subscriptions
  {
    id: "sub-fab-1",
    microsoftSubscriptionId: "d4e5f6a7-b8c9-0123-def0-111111111111",
    offerId: "CFQ7TTC0LFLZ",
    productName: "Microsoft 365 E5",
    skuName: "Microsoft 365 E5",
    quantity: 500,
    billingCycle: "Annual",
    termDuration: "P1Y",
    monthlyValue: 28500,
    status: "Active",
    isTransferable: true,
    customerName: "Fabrikam Inc",
    customerId: "cust-004"
  },
  {
    id: "sub-fab-2",
    microsoftSubscriptionId: "d4e5f6a7-b8c9-0123-def0-222222222222",
    offerId: "CFQ7TTC0LHXM",
    productName: "Microsoft Defender for Business",
    skuName: "Defender for Business",
    quantity: 500,
    billingCycle: "Monthly",
    termDuration: "P1Y",
    monthlyValue: 2500,
    status: "Active",
    isTransferable: true,
    customerName: "Fabrikam Inc",
    customerId: "cust-004"
  },
  // Adventure Works subscriptions
  {
    id: "sub-aw-1",
    microsoftSubscriptionId: "e5f6a7b8-c9d0-1234-ef01-111111111111",
    offerId: "CFQ7TTC0LFLX",
    productName: "Microsoft 365 E3",
    skuName: "Microsoft 365 E3",
    quantity: 25,
    billingCycle: "Monthly",
    termDuration: "P1Y",
    monthlyValue: 900,
    status: "Active",
    isTransferable: true,
    customerName: "Adventure Works",
    customerId: "cust-005"
  }
];
function findSubscriptionById(id) {
  return mockSearchableSubscriptions.find((s) => s.id === id);
}
function getSubscriptionsByIds(ids) {
  return ids.map((id) => findSubscriptionById(id)).filter((s) => s !== void 0);
}
function calculateTotalValue(ids) {
  return getSubscriptionsByIds(ids).filter((s) => s.isTransferable).reduce((sum, s) => sum + s.monthlyValue, 0);
}

const {useState: useState$3,useEffect,useCallback: useCallback$1} = await importShared('react');

const {Modal: Modal$2,Button: Button$3,TextInput: TextInput$1,Text: Text$5,Group: Group$5,Stack: Stack$4,Table: Table$4,Card: Card$4,Checkbox: Checkbox$1,Divider: Divider$3,Alert: Alert$3,ThemeIcon: ThemeIcon$4,SegmentedControl,ActionIcon: ActionIcon$2,Loader: Loader$2,Center: Center$2,Stepper} = await importShared('@mantine/core');
function CreateTransferModal({
  open,
  onClose,
  selectedSubscriptionIds = []
}) {
  const { create, submitting } = useTransfers();
  const [active, setActive] = useState$3(0);
  const [targetTenantId, setTargetTenantId] = useState$3("");
  const [targetMpnId, setTargetMpnId] = useState$3("");
  const [selectedSubs, setSelectedSubs] = useState$3(selectedSubscriptionIds);
  const [errors, setErrors] = useState$3([]);
  const [searchType, setSearchType] = useState$3("customer");
  const [searchQuery, setSearchQuery] = useState$3("");
  const [isSearching, setIsSearching] = useState$3(false);
  const [searchResults, setSearchResults] = useState$3([]);
  const [hasSearched, setHasSearched] = useState$3(false);
  useEffect(() => {
    if (open) {
      const hasPreselectedSubs = selectedSubscriptionIds.length > 0;
      setActive(hasPreselectedSubs ? 1 : 0);
      setSelectedSubs(selectedSubscriptionIds);
      setErrors([]);
      setSearchQuery("");
      setSearchResults([]);
      setHasSearched(false);
      setTargetTenantId("");
      setTargetMpnId("");
    }
  }, [open, selectedSubscriptionIds]);
  const handleSearch = useCallback$1(async () => {
    if (!searchQuery.trim()) return;
    setIsSearching(true);
    setHasSearched(true);
    await new Promise((resolve) => setTimeout(resolve, 400));
    const query = searchQuery.toLowerCase().trim();
    const results = mockSearchableSubscriptions.filter((sub) => {
      if (searchType === "customer") {
        return sub.customerName.toLowerCase().includes(query) || sub.customerId.toLowerCase().includes(query);
      } else {
        return sub.microsoftSubscriptionId.toLowerCase().includes(query) || sub.productName.toLowerCase().includes(query);
      }
    });
    setSearchResults(results);
    setIsSearching(false);
  }, [searchQuery, searchType]);
  const handleKeyDown = (e) => {
    if (e.key === "Enter") handleSearch();
  };
  const toggleSubscription = (subId) => {
    setSelectedSubs((prev) => prev.includes(subId) ? prev.filter((id) => id !== subId) : [...prev, subId]);
  };
  const selectedSubscriptions = getSubscriptionsByIds(selectedSubs);
  const totalValue = calculateTotalValue(selectedSubs);
  const handleNext = () => {
    if (active === 0) {
      if (selectedSubs.length === 0) {
        setErrors(["Select at least one subscription"]);
        return;
      }
      setErrors([]);
      setActive(1);
    } else if (active === 1) {
      const validation = validateCreateTransferInput({
        targetPartnerTenantId: targetTenantId,
        targetPartnerMpnId: targetMpnId || void 0,
        subscriptionIds: selectedSubs
      });
      if (!validation.valid) {
        setErrors(validation.errors);
        return;
      }
      setErrors([]);
      setActive(2);
    }
  };
  const handleBack = () => {
    setErrors([]);
    setActive((prev) => Math.max(0, prev - 1));
  };
  const handleSubmit = async () => {
    try {
      await create({
        targetPartnerTenantId: targetTenantId,
        targetPartnerMpnId: targetMpnId || void 0,
        subscriptionIds: selectedSubs
      });
      notifications.show({
        title: "Transfer Request Sent",
        message: `${selectedSubs.length} subscription(s) transfer request sent to target partner.`,
        color: "green"
      });
      onClose();
    } catch (err) {
      notifications.show({
        title: "Transfer Failed",
        message: err instanceof Error ? err.message : "Failed to create transfer request",
        color: "red"
      });
    }
  };
  const groupedResults = searchResults.reduce((acc, sub) => {
    if (!acc[sub.customerId]) {
      acc[sub.customerId] = { customerName: sub.customerName, customerId: sub.customerId, subscriptions: [] };
    }
    acc[sub.customerId].subscriptions.push(sub);
    return acc;
  }, {});
  return /* @__PURE__ */ jsxRuntimeExports.jsx(
    Modal$2,
    {
      opened: open,
      onClose,
      title: /* @__PURE__ */ jsxRuntimeExports.jsxs(Group$5, { gap: "xs", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(ThemeIcon$4, { size: "md", color: "teal", variant: "light", children: /* @__PURE__ */ jsxRuntimeExports.jsx(ArrowUpRight, { size: 16 }) }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(Text$5, { fw: 600, children: "Create Outbound Transfer" })
      ] }),
      size: "xl",
      centered: true,
      children: /* @__PURE__ */ jsxRuntimeExports.jsxs(Stack$4, { gap: "md", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs(Stepper, { active, size: "sm", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(Stepper.Step, { label: "Select Subscriptions", description: "Search and select" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(Stepper.Step, { label: "Target Partner", description: "Enter partner details" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(Stepper.Step, { label: "Confirm", description: "Review and submit" })
        ] }),
        errors.length > 0 && /* @__PURE__ */ jsxRuntimeExports.jsx(Alert$3, { icon: /* @__PURE__ */ jsxRuntimeExports.jsx(AlertCircle, { size: 16 }), title: "Validation Error", color: "red", children: /* @__PURE__ */ jsxRuntimeExports.jsx("ul", { style: { margin: 0, paddingLeft: 16 }, children: errors.map((error, i) => /* @__PURE__ */ jsxRuntimeExports.jsx("li", { children: error }, i)) }) }),
        active === 0 && /* @__PURE__ */ jsxRuntimeExports.jsxs(Stack$4, { gap: "md", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(Alert$3, { icon: /* @__PURE__ */ jsxRuntimeExports.jsx(Info, { size: 16 }), color: "blue", variant: "light", children: /* @__PURE__ */ jsxRuntimeExports.jsx(Text$5, { size: "sm", children: "Search for subscriptions by customer or subscription ID to include in this transfer." }) }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(Card$4, { withBorder: true, padding: "sm", bg: "gray.0", children: /* @__PURE__ */ jsxRuntimeExports.jsxs(Stack$4, { gap: "sm", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs(Group$5, { gap: "xs", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(Text$5, { size: "sm", fw: 500, children: "Search by:" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx(
                SegmentedControl,
                {
                  size: "xs",
                  value: searchType,
                  onChange: (v) => setSearchType(v),
                  data: [
                    { label: "Customer", value: "customer" },
                    { label: "Subscription", value: "subscription" }
                  ]
                }
              )
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs(Group$5, { gap: "xs", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(
                TextInput$1,
                {
                  placeholder: searchType === "customer" ? 'Enter customer name (e.g., "Woodgrove", "Contoso")...' : "Enter subscription ID or product name...",
                  value: searchQuery,
                  onChange: (e) => setSearchQuery(e.currentTarget.value),
                  onKeyDown: handleKeyDown,
                  leftSection: /* @__PURE__ */ jsxRuntimeExports.jsx(Search, { size: 14 }),
                  rightSection: searchQuery && /* @__PURE__ */ jsxRuntimeExports.jsx(ActionIcon$2, { size: "xs", variant: "subtle", onClick: () => {
                    setSearchQuery("");
                    setSearchResults([]);
                    setHasSearched(false);
                  }, children: /* @__PURE__ */ jsxRuntimeExports.jsx(X, { size: 12 }) }),
                  style: { flex: 1 }
                }
              ),
              /* @__PURE__ */ jsxRuntimeExports.jsx(Button$3, { size: "sm", onClick: handleSearch, loading: isSearching, disabled: !searchQuery.trim(), children: "Search" })
            ] })
          ] }) }),
          isSearching && /* @__PURE__ */ jsxRuntimeExports.jsx(Center$2, { py: "md", children: /* @__PURE__ */ jsxRuntimeExports.jsx(Loader$2, { size: "sm" }) }),
          !isSearching && hasSearched && searchResults.length === 0 && /* @__PURE__ */ jsxRuntimeExports.jsxs(Alert$3, { icon: /* @__PURE__ */ jsxRuntimeExports.jsx(AlertCircle, { size: 16 }), color: "gray", variant: "light", children: [
            'No subscriptions found matching "',
            searchQuery,
            '".'
          ] }),
          !isSearching && searchResults.length > 0 && /* @__PURE__ */ jsxRuntimeExports.jsxs(Stack$4, { gap: "sm", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs(Text$5, { size: "sm", c: "dimmed", children: [
              "Found ",
              /* @__PURE__ */ jsxRuntimeExports.jsx("strong", { children: searchResults.length }),
              " subscription(s) across ",
              /* @__PURE__ */ jsxRuntimeExports.jsx("strong", { children: Object.keys(groupedResults).length }),
              " customer(s)"
            ] }),
            Object.values(groupedResults).map((group) => /* @__PURE__ */ jsxRuntimeExports.jsxs(Card$4, { withBorder: true, padding: "xs", radius: "md", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsxs(Group$5, { gap: "xs", mb: "xs", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx(ThemeIcon$4, { size: "sm", color: "blue", variant: "light", children: /* @__PURE__ */ jsxRuntimeExports.jsx(Building2, { size: 12 }) }),
                /* @__PURE__ */ jsxRuntimeExports.jsx(Text$5, { size: "sm", fw: 600, children: group.customerName })
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs(Table$4, { striped: true, highlightOnHover: true, withTableBorder: true, children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx(Table$4.Thead, { children: /* @__PURE__ */ jsxRuntimeExports.jsxs(Table$4.Tr, { children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx(Table$4.Th, { style: { width: 40 } }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx(Table$4.Th, { children: "Product" }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx(Table$4.Th, { children: "Qty" }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx(Table$4.Th, { children: "Est. Value/mo" })
                ] }) }),
                /* @__PURE__ */ jsxRuntimeExports.jsx(Table$4.Tbody, { children: group.subscriptions.map((sub) => /* @__PURE__ */ jsxRuntimeExports.jsxs(Table$4.Tr, { style: { backgroundColor: selectedSubs.includes(sub.id) ? "var(--mantine-color-teal-0)" : void 0 }, children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx(Table$4.Td, { children: /* @__PURE__ */ jsxRuntimeExports.jsx(
                    Checkbox$1,
                    {
                      checked: selectedSubs.includes(sub.id),
                      onChange: () => toggleSubscription(sub.id),
                      disabled: !sub.isTransferable
                    }
                  ) }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx(Table$4.Td, { children: /* @__PURE__ */ jsxRuntimeExports.jsx(Text$5, { size: "sm", fw: 500, children: sub.productName }) }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx(Table$4.Td, { children: sub.quantity }),
                  /* @__PURE__ */ jsxRuntimeExports.jsxs(Table$4.Td, { children: [
                    "~",
                    formatCurrency(sub.monthlyValue)
                  ] })
                ] }, sub.id)) })
              ] })
            ] }, group.customerId))
          ] }),
          selectedSubs.length > 0 && /* @__PURE__ */ jsxRuntimeExports.jsx(Card$4, { withBorder: true, bg: "teal.0", padding: "sm", children: /* @__PURE__ */ jsxRuntimeExports.jsxs(Group$5, { justify: "space-between", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs(Text$5, { size: "sm", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("strong", { children: selectedSubs.length }),
              " subscription(s) selected"
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs(Text$5, { size: "sm", children: [
              "Est. Total: ",
              /* @__PURE__ */ jsxRuntimeExports.jsxs("strong", { children: [
                "~",
                formatCurrency(totalValue),
                "/mo"
              ] })
            ] })
          ] }) }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs(Group$5, { justify: "flex-end", gap: "xs", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(Button$3, { variant: "default", onClick: onClose, children: "Cancel" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx(Button$3, { onClick: handleNext, disabled: selectedSubs.length === 0, children: "Continue" })
          ] })
        ] }),
        active === 1 && /* @__PURE__ */ jsxRuntimeExports.jsxs(Stack$4, { gap: "md", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(Alert$3, { icon: /* @__PURE__ */ jsxRuntimeExports.jsx(Info, { size: 16 }), color: "blue", variant: "light", children: /* @__PURE__ */ jsxRuntimeExports.jsx(Text$5, { size: "sm", children: "Enter the Microsoft Partner Centre details for the partner receiving these subscriptions." }) }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs(Card$4, { withBorder: true, padding: "md", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(Text$5, { size: "sm", fw: 600, mb: "md", children: "Target Partner Information" }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs(Stack$4, { gap: "sm", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(
                TextInput$1,
                {
                  label: "Target Partner Tenant ID",
                  placeholder: "e.g., a1b2c3d4-e5f6-7890-abcd-ef1234567890",
                  value: targetTenantId,
                  onChange: (e) => setTargetTenantId(e.currentTarget.value),
                  error: targetTenantId && !isValidTenantId(targetTenantId) ? "Invalid GUID format" : void 0,
                  required: true
                }
              ),
              /* @__PURE__ */ jsxRuntimeExports.jsx(
                TextInput$1,
                {
                  label: "MPN ID (optional)",
                  placeholder: "e.g., 1234567",
                  value: targetMpnId,
                  onChange: (e) => setTargetMpnId(e.currentTarget.value)
                }
              )
            ] })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs(Card$4, { withBorder: true, bg: "gray.0", padding: "sm", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(Text$5, { size: "xs", c: "dimmed", fw: 600, mb: "xs", children: "SELECTED SUBSCRIPTIONS" }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs(Text$5, { size: "sm", children: [
              selectedSubs.length,
              " subscription(s) • Est. ~",
              formatCurrency(totalValue),
              "/mo"
            ] })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs(Group$5, { justify: "flex-end", gap: "xs", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(Button$3, { variant: "default", onClick: handleBack, children: "Back" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx(Button$3, { onClick: handleNext, disabled: !targetTenantId, children: "Continue" })
          ] })
        ] }),
        active === 2 && /* @__PURE__ */ jsxRuntimeExports.jsxs(Stack$4, { gap: "md", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(Alert$3, { icon: /* @__PURE__ */ jsxRuntimeExports.jsx(AlertCircle, { size: 16 }), color: "yellow", variant: "light", children: /* @__PURE__ */ jsxRuntimeExports.jsx(Text$5, { size: "sm", children: "Please confirm this transfer request. The target partner will have 30 days to accept." }) }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(Card$4, { withBorder: true, padding: "sm", children: /* @__PURE__ */ jsxRuntimeExports.jsxs(Stack$4, { gap: "xs", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs(Group$5, { justify: "space-between", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(Text$5, { size: "sm", c: "dimmed", children: "Target Tenant ID" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx(Text$5, { size: "sm", fw: 500, ff: "monospace", children: targetTenantId })
            ] }),
            targetMpnId && /* @__PURE__ */ jsxRuntimeExports.jsxs(Group$5, { justify: "space-between", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(Text$5, { size: "sm", c: "dimmed", children: "MPN ID" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx(Text$5, { size: "sm", fw: 500, children: targetMpnId })
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsx(Divider$3, {}),
            /* @__PURE__ */ jsxRuntimeExports.jsxs(Group$5, { justify: "space-between", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(Text$5, { size: "sm", c: "dimmed", children: "Subscriptions" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx(Text$5, { size: "sm", fw: 500, children: selectedSubs.length })
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs(Group$5, { justify: "space-between", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(Text$5, { size: "sm", c: "dimmed", children: "Est. Monthly Value" }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs(Text$5, { size: "lg", fw: 700, children: [
                "~",
                formatCurrency(totalValue)
              ] })
            ] })
          ] }) }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs(Table$4, { striped: true, highlightOnHover: true, withTableBorder: true, children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(Table$4.Thead, { children: /* @__PURE__ */ jsxRuntimeExports.jsxs(Table$4.Tr, { children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(Table$4.Th, { children: "Customer" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx(Table$4.Th, { children: "Product" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx(Table$4.Th, { children: "Qty" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx(Table$4.Th, { children: "Est. Value/mo" })
            ] }) }),
            /* @__PURE__ */ jsxRuntimeExports.jsx(Table$4.Tbody, { children: selectedSubscriptions.map((sub) => /* @__PURE__ */ jsxRuntimeExports.jsxs(Table$4.Tr, { children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(Table$4.Td, { children: /* @__PURE__ */ jsxRuntimeExports.jsx(Text$5, { size: "xs", c: "dimmed", children: sub.customerName }) }),
              /* @__PURE__ */ jsxRuntimeExports.jsx(Table$4.Td, { children: /* @__PURE__ */ jsxRuntimeExports.jsx(Text$5, { size: "sm", children: sub.productName }) }),
              /* @__PURE__ */ jsxRuntimeExports.jsx(Table$4.Td, { children: sub.quantity }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs(Table$4.Td, { children: [
                "~",
                formatCurrency(sub.monthlyValue)
              ] })
            ] }, sub.id)) })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs(Group$5, { justify: "flex-end", gap: "xs", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(Button$3, { variant: "default", onClick: handleBack, children: "Back" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx(Button$3, { loading: submitting, onClick: handleSubmit, children: "Confirm Transfer" })
          ] })
        ] })
      ] })
    }
  );
}

const {useState: useState$2} = await importShared('react');

const {Modal: Modal$1,Button: Button$2,Text: Text$4,Group: Group$4,Stack: Stack$3,Table: Table$3,Card: Card$3,Divider: Divider$2,Alert: Alert$2,ThemeIcon: ThemeIcon$3,Select,Textarea,Badge: Badge$4} = await importShared('@mantine/core');
function ReviewTransferModal({
  open,
  onClose,
  transfer,
  onAccept,
  onReject
}) {
  const [showRejectForm, setShowRejectForm] = useState$2(false);
  const [rejectionReason, setRejectionReason] = useState$2(null);
  const [customReason, setCustomReason] = useState$2("");
  const [isProcessing, setIsProcessing] = useState$2(false);
  if (!transfer) return null;
  const daysRemaining = getDaysUntilExpiration(transfer.expirationDate);
  const isUrgent = daysRemaining <= 7;
  const handleAccept = async () => {
    setIsProcessing(true);
    try {
      await onAccept();
    } finally {
      setIsProcessing(false);
    }
  };
  const handleReject = async () => {
    const reason = rejectionReason === "other" ? customReason : REJECTION_REASONS.find((r) => r.value === rejectionReason)?.label || "No reason provided";
    setIsProcessing(true);
    try {
      await onReject(reason);
      setShowRejectForm(false);
      setRejectionReason(null);
      setCustomReason("");
    } finally {
      setIsProcessing(false);
    }
  };
  return /* @__PURE__ */ jsxRuntimeExports.jsx(
    Modal$1,
    {
      opened: open,
      onClose,
      title: /* @__PURE__ */ jsxRuntimeExports.jsxs(Group$4, { gap: "xs", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(ThemeIcon$3, { size: "md", color: "blue", variant: "light", children: /* @__PURE__ */ jsxRuntimeExports.jsx(ArrowDownLeft, { size: 16 }) }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(Text$4, { fw: 600, children: "Review Incoming Transfer" })
      ] }),
      size: "lg",
      centered: true,
      children: /* @__PURE__ */ jsxRuntimeExports.jsxs(Stack$3, { gap: "md", children: [
        isUrgent && /* @__PURE__ */ jsxRuntimeExports.jsx(Alert$2, { icon: /* @__PURE__ */ jsxRuntimeExports.jsx(Clock, { size: 16 }), color: "orange", variant: "filled", children: /* @__PURE__ */ jsxRuntimeExports.jsxs(Text$4, { size: "sm", fw: 500, children: [
          "This transfer expires in ",
          daysRemaining,
          " days. Please review promptly."
        ] }) }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs(Card$3, { withBorder: true, padding: "sm", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs(Group$4, { gap: "xs", mb: "xs", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(Building2, { size: 14, className: "text-gray-500" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx(Text$4, { size: "xs", c: "dimmed", tt: "uppercase", fw: 600, children: "Source Partner" })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs(Stack$3, { gap: 4, children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs(Group$4, { justify: "space-between", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(Text$4, { size: "sm", c: "dimmed", children: "Partner Name" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx(Text$4, { size: "sm", fw: 500, children: transfer.sourcePartner.name })
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs(Group$4, { justify: "space-between", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(Text$4, { size: "sm", c: "dimmed", children: "Tenant ID" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx(Text$4, { size: "xs", ff: "monospace", c: "dimmed", children: transfer.sourcePartner.tenantId })
            ] }),
            transfer.sourcePartner.mpnId && /* @__PURE__ */ jsxRuntimeExports.jsxs(Group$4, { justify: "space-between", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(Text$4, { size: "sm", c: "dimmed", children: "MPN ID" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx(Text$4, { size: "sm", children: transfer.sourcePartner.mpnId })
            ] })
          ] })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { style: { display: "grid", gridTemplateColumns: "repeat(3, 1fr)", gap: "12px" }, children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs(Card$3, { withBorder: true, padding: "sm", ta: "center", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(Text$4, { size: "xs", c: "dimmed", children: "Subscriptions" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx(Text$4, { size: "lg", fw: 700, children: transfer.lineItems.length })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs(Card$3, { withBorder: true, padding: "sm", ta: "center", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(Text$4, { size: "xs", c: "dimmed", children: "Est. Monthly Value" }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs(Text$4, { size: "lg", fw: 700, children: [
              "~",
              formatCurrency(transfer.totalMonthlyValue)
            ] })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs(Card$3, { withBorder: true, padding: "sm", ta: "center", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(Text$4, { size: "xs", c: "dimmed", children: "Expires" }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs(Group$4, { gap: 4, justify: "center", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsxs(Text$4, { size: "lg", fw: 700, children: [
                daysRemaining,
                "d"
              ] }),
              isUrgent && /* @__PURE__ */ jsxRuntimeExports.jsx(Badge$4, { size: "xs", color: "red", children: "URGENT" })
            ] })
          ] })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(Divider$2, {}),
        /* @__PURE__ */ jsxRuntimeExports.jsx(Text$4, { size: "sm", fw: 600, children: "Subscriptions to be Transferred" }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs(Table$3, { striped: true, highlightOnHover: true, withTableBorder: true, children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(Table$3.Thead, { children: /* @__PURE__ */ jsxRuntimeExports.jsxs(Table$3.Tr, { children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(Table$3.Th, { children: "Product" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx(Table$3.Th, { children: "Qty" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx(Table$3.Th, { children: "Billing" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx(Table$3.Th, { children: "Est. Value/mo" })
          ] }) }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(Table$3.Tbody, { children: transfer.lineItems.map((item) => /* @__PURE__ */ jsxRuntimeExports.jsxs(Table$3.Tr, { children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs(Table$3.Td, { children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(Text$4, { size: "sm", fw: 500, children: item.productName }),
              /* @__PURE__ */ jsxRuntimeExports.jsx(Text$4, { size: "xs", c: "dimmed", children: item.skuName })
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsx(Table$3.Td, { children: item.quantity }),
            /* @__PURE__ */ jsxRuntimeExports.jsx(Table$3.Td, { children: item.billingCycle }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs(Table$3.Td, { children: [
              "~",
              formatCurrency(item.monthlyValue)
            ] })
          ] }, item.id)) })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(Divider$2, {}),
        showRejectForm ? /* @__PURE__ */ jsxRuntimeExports.jsx(Card$3, { withBorder: true, bg: "gray.0", padding: "md", children: /* @__PURE__ */ jsxRuntimeExports.jsxs(Stack$3, { gap: "sm", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(Text$4, { size: "sm", fw: 600, children: "Reason for Rejection" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(
            Select,
            {
              placeholder: "Select a reason",
              data: REJECTION_REASONS.map((r) => ({ value: r.value, label: r.label })),
              value: rejectionReason,
              onChange: setRejectionReason
            }
          ),
          rejectionReason === "other" && /* @__PURE__ */ jsxRuntimeExports.jsx(
            Textarea,
            {
              placeholder: "Please provide details...",
              value: customReason,
              onChange: (e) => setCustomReason(e.currentTarget.value),
              minRows: 2
            }
          ),
          /* @__PURE__ */ jsxRuntimeExports.jsxs(Group$4, { justify: "flex-end", gap: "xs", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(Button$2, { variant: "default", size: "xs", onClick: () => setShowRejectForm(false), children: "Cancel" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx(
              Button$2,
              {
                color: "red",
                size: "xs",
                onClick: handleReject,
                loading: isProcessing,
                disabled: !rejectionReason || rejectionReason === "other" && !customReason,
                children: "Confirm Rejection"
              }
            )
          ] })
        ] }) }) : /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(Alert$2, { icon: /* @__PURE__ */ jsxRuntimeExports.jsx(AlertCircle, { size: 16 }), color: "blue", variant: "light", children: /* @__PURE__ */ jsxRuntimeExports.jsxs(Text$4, { size: "sm", children: [
            "By accepting this transfer, you agree to take over the management of these subscriptions. The transfer will be worth an estimated ",
            formatCurrency(transfer.totalMonthlyValue),
            "/month."
          ] }) }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs(Group$4, { justify: "flex-end", gap: "xs", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(Button$2, { variant: "default", onClick: onClose, children: "Cancel" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx(
              Button$2,
              {
                variant: "light",
                color: "red",
                onClick: () => setShowRejectForm(true),
                children: "Reject"
              }
            ),
            /* @__PURE__ */ jsxRuntimeExports.jsx(
              Button$2,
              {
                color: "green",
                onClick: handleAccept,
                loading: isProcessing,
                children: "Accept Transfer"
              }
            )
          ] })
        ] })
      ] })
    }
  );
}

const {Modal,Text: Text$3,Group: Group$3,Stack: Stack$2,Table: Table$2,Card: Card$2,Divider: Divider$1,ThemeIcon: ThemeIcon$2,Timeline,Badge: Badge$3} = await importShared('@mantine/core');
function TransferDetailsModal({
  open,
  onClose,
  transfer
}) {
  if (!transfer) return null;
  const isIncoming = transfer.direction === "Incoming";
  const daysRemaining = getDaysUntilExpiration(transfer.expirationDate);
  const isUrgent = daysRemaining <= 7 && transfer.status === "Pending";
  const getTimelineItems = () => {
    const items = [
      {
        title: "Transfer Created",
        date: transfer.createdDate,
        description: `Transfer request initiated by ${isIncoming ? transfer.sourcePartner.name : "you"}`,
        icon: /* @__PURE__ */ jsxRuntimeExports.jsx(Send, { size: 12 }),
        color: "blue",
        active: true
      }
    ];
    if (transfer.status === "Completed") {
      items.push({
        title: "Transfer Accepted",
        date: transfer.lastModifiedDate,
        description: `Transfer accepted by ${isIncoming ? "you" : transfer.targetPartner.name}`,
        icon: /* @__PURE__ */ jsxRuntimeExports.jsx(FileCheck, { size: 12 }),
        color: "green",
        active: true
      });
      items.push({
        title: "Transfer Completed",
        date: transfer.completedDate || transfer.lastModifiedDate,
        description: "All subscriptions successfully transferred",
        icon: /* @__PURE__ */ jsxRuntimeExports.jsx(CheckCircle, { size: 12 }),
        color: "green",
        active: true
      });
    } else if (transfer.status === "Rejected") {
      items.push({
        title: "Transfer Rejected",
        date: transfer.lastModifiedDate,
        description: transfer.rejectionReason || "Transfer was rejected",
        icon: /* @__PURE__ */ jsxRuntimeExports.jsx(XCircle, { size: 12 }),
        color: "red",
        active: true
      });
    } else if (transfer.status === "Cancelled") {
      items.push({
        title: "Transfer Cancelled",
        date: transfer.lastModifiedDate,
        description: "Transfer was cancelled by the initiating partner",
        icon: /* @__PURE__ */ jsxRuntimeExports.jsx(XCircle, { size: 12 }),
        color: "gray",
        active: true
      });
    } else if (transfer.status === "Pending") {
      items.push({
        title: "Awaiting Response",
        date: "",
        description: `Expires on ${formatDate(transfer.expirationDate)}`,
        icon: /* @__PURE__ */ jsxRuntimeExports.jsx(Clock, { size: 12 }),
        color: "yellow",
        active: true
      });
    }
    return items;
  };
  return /* @__PURE__ */ jsxRuntimeExports.jsx(
    Modal,
    {
      opened: open,
      onClose,
      title: /* @__PURE__ */ jsxRuntimeExports.jsxs(Group$3, { gap: "xs", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(
          ThemeIcon$2,
          {
            size: "md",
            color: isIncoming ? "blue" : "teal",
            variant: "light",
            children: isIncoming ? /* @__PURE__ */ jsxRuntimeExports.jsx(ArrowDownLeft, { size: 16 }) : /* @__PURE__ */ jsxRuntimeExports.jsx(ArrowUpRight, { size: 16 })
          }
        ),
        /* @__PURE__ */ jsxRuntimeExports.jsx(Text$3, { fw: 600, children: "Transfer Details" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(TransferStatusBadge, { status: transfer.status })
      ] }),
      size: "xl",
      centered: true,
      children: /* @__PURE__ */ jsxRuntimeExports.jsxs(Stack$2, { gap: "md", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { style: { display: "grid", gridTemplateColumns: "1fr 1fr", gap: "12px" }, children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs(Card$2, { withBorder: true, padding: "sm", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs(Group$3, { gap: "xs", mb: "xs", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(Building2, { size: 14, className: "text-gray-500" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx(Text$3, { size: "xs", c: "dimmed", tt: "uppercase", fw: 600, children: "Source Partner" })
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs(Stack$2, { gap: 2, children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(Text$3, { size: "sm", fw: 500, children: transfer.sourcePartner.name }),
              /* @__PURE__ */ jsxRuntimeExports.jsx(Text$3, { size: "xs", ff: "monospace", c: "dimmed", children: transfer.sourcePartner.tenantId }),
              transfer.sourcePartner.mpnId && /* @__PURE__ */ jsxRuntimeExports.jsxs(Text$3, { size: "xs", c: "dimmed", children: [
                "MPN: ",
                transfer.sourcePartner.mpnId
              ] })
            ] })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs(Card$2, { withBorder: true, padding: "sm", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs(Group$3, { gap: "xs", mb: "xs", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(Building2, { size: 14, className: "text-gray-500" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx(Text$3, { size: "xs", c: "dimmed", tt: "uppercase", fw: 600, children: "Target Partner" })
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs(Stack$2, { gap: 2, children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(Text$3, { size: "sm", fw: 500, children: transfer.targetPartner.name }),
              /* @__PURE__ */ jsxRuntimeExports.jsx(Text$3, { size: "xs", ff: "monospace", c: "dimmed", children: transfer.targetPartner.tenantId }),
              transfer.targetPartner.mpnId && /* @__PURE__ */ jsxRuntimeExports.jsxs(Text$3, { size: "xs", c: "dimmed", children: [
                "MPN: ",
                transfer.targetPartner.mpnId
              ] })
            ] })
          ] })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { style: { display: "grid", gridTemplateColumns: "repeat(4, 1fr)", gap: "12px" }, children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs(Card$2, { withBorder: true, padding: "sm", ta: "center", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(Text$3, { size: "xs", c: "dimmed", children: "Subscriptions" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx(Text$3, { size: "lg", fw: 700, children: transfer.lineItems.length })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs(Card$2, { withBorder: true, padding: "sm", ta: "center", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(Text$3, { size: "xs", c: "dimmed", children: "Est. Monthly Value" }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs(Text$3, { size: "lg", fw: 700, children: [
              "~",
              formatCurrency(transfer.totalMonthlyValue)
            ] })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs(Card$2, { withBorder: true, padding: "sm", ta: "center", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(Text$3, { size: "xs", c: "dimmed", children: "Created" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx(Text$3, { size: "sm", fw: 500, children: formatDate(transfer.createdDate) })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs(Card$2, { withBorder: true, padding: "sm", ta: "center", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(Text$3, { size: "xs", c: "dimmed", children: transfer.status === "Pending" ? "Expires" : "Last Update" }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs(Group$3, { gap: 4, justify: "center", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(Text$3, { size: "sm", fw: 500, children: transfer.status === "Pending" ? formatDate(transfer.expirationDate) : formatDate(transfer.lastModifiedDate) }),
              isUrgent && /* @__PURE__ */ jsxRuntimeExports.jsx(Badge$3, { size: "xs", color: "red", children: "URGENT" })
            ] })
          ] })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(Divider$1, {}),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { style: { display: "grid", gridTemplateColumns: "2fr 1fr", gap: "16px" }, children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs(Stack$2, { gap: "xs", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(Text$3, { size: "sm", fw: 600, children: "Subscription Line Items" }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs(Table$2, { striped: true, highlightOnHover: true, withTableBorder: true, children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(Table$2.Thead, { children: /* @__PURE__ */ jsxRuntimeExports.jsxs(Table$2.Tr, { children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx(Table$2.Th, { children: "Product" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx(Table$2.Th, { children: "Qty" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx(Table$2.Th, { children: "Billing" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx(Table$2.Th, { children: "Est. Value/mo" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx(Table$2.Th, { children: "Status" })
              ] }) }),
              /* @__PURE__ */ jsxRuntimeExports.jsx(Table$2.Tbody, { children: transfer.lineItems.map((item) => /* @__PURE__ */ jsxRuntimeExports.jsxs(Table$2.Tr, { children: [
                /* @__PURE__ */ jsxRuntimeExports.jsxs(Table$2.Td, { children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx(Text$3, { size: "sm", fw: 500, children: item.productName }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx(Text$3, { size: "xs", c: "dimmed", children: item.skuName })
                ] }),
                /* @__PURE__ */ jsxRuntimeExports.jsx(Table$2.Td, { children: item.quantity }),
                /* @__PURE__ */ jsxRuntimeExports.jsx(Table$2.Td, { children: item.billingCycle }),
                /* @__PURE__ */ jsxRuntimeExports.jsxs(Table$2.Td, { children: [
                  "~",
                  formatCurrency(item.monthlyValue)
                ] }),
                /* @__PURE__ */ jsxRuntimeExports.jsx(Table$2.Td, { children: /* @__PURE__ */ jsxRuntimeExports.jsx(
                  Badge$3,
                  {
                    size: "xs",
                    color: item.status === "Transferred" ? "green" : item.status === "Failed" ? "red" : "yellow",
                    variant: "light",
                    children: item.status
                  }
                ) })
              ] }, item.id)) })
            ] })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs(Stack$2, { gap: "xs", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(Text$3, { size: "sm", fw: 600, children: "Activity Timeline" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx(Card$2, { withBorder: true, padding: "sm", children: /* @__PURE__ */ jsxRuntimeExports.jsx(Timeline, { active: getTimelineItems().length - 1, bulletSize: 24, lineWidth: 2, children: getTimelineItems().map((item, index) => /* @__PURE__ */ jsxRuntimeExports.jsxs(
              Timeline.Item,
              {
                bullet: item.icon,
                title: /* @__PURE__ */ jsxRuntimeExports.jsx(Text$3, { size: "sm", fw: 500, children: item.title }),
                color: item.color,
                children: [
                  item.date && /* @__PURE__ */ jsxRuntimeExports.jsx(Text$3, { size: "xs", c: "dimmed", mt: 2, children: formatDateTime(item.date) }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx(Text$3, { size: "xs", mt: 4, children: item.description })
                ]
              },
              index
            )) }) })
          ] })
        ] }),
        transfer.rejectionReason && /* @__PURE__ */ jsxRuntimeExports.jsxs(Card$2, { withBorder: true, bg: "red.0", padding: "sm", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs(Group$3, { gap: "xs", mb: "xs", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(XCircle, { size: 14, className: "text-red-500" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx(Text$3, { size: "xs", c: "red", tt: "uppercase", fw: 600, children: "Rejection Reason" })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(Text$3, { size: "sm", children: transfer.rejectionReason })
        ] })
      ] })
    }
  );
}

const {useState: useState$1,useCallback} = await importShared('react');

const {TextInput,Button: Button$1,Group: Group$2,Stack: Stack$1,Table: Table$1,Text: Text$2,Checkbox,Card: Card$1,Badge: Badge$2,ActionIcon: ActionIcon$1,Tooltip: Tooltip$1,Alert: Alert$1,Loader: Loader$1,Center: Center$1,ThemeIcon: ThemeIcon$1} = await importShared('@mantine/core');
function SubscriptionSearch({
  selectedSubscriptions,
  onSelectionChange,
  onInitiateTransfer
}) {
  const [searchQuery, setSearchQuery] = useState$1("");
  const [isSearching, setIsSearching] = useState$1(false);
  const [searchResults, setSearchResults] = useState$1([]);
  const [hasSearched, setHasSearched] = useState$1(false);
  const handleSearch = useCallback(async () => {
    if (!searchQuery.trim()) return;
    setIsSearching(true);
    setHasSearched(true);
    await new Promise((resolve) => setTimeout(resolve, 500));
    const query = searchQuery.toLowerCase().trim();
    const results = mockSearchableSubscriptions.filter(
      (sub) => sub.customerName.toLowerCase().includes(query) || sub.customerId.toLowerCase().includes(query) || sub.microsoftSubscriptionId.toLowerCase().includes(query) || sub.id.toLowerCase().includes(query) || sub.productName.toLowerCase().includes(query) || sub.skuName.toLowerCase().includes(query)
    );
    setSearchResults(results);
    setIsSearching(false);
  }, [searchQuery]);
  const handleKeyDown = (e) => {
    if (e.key === "Enter") {
      handleSearch();
    }
  };
  const clearSearch = () => {
    setSearchQuery("");
    setSearchResults([]);
    setHasSearched(false);
    onSelectionChange([]);
  };
  const toggleSubscription = (subId) => {
    if (selectedSubscriptions.includes(subId)) {
      onSelectionChange(selectedSubscriptions.filter((id) => id !== subId));
    } else {
      onSelectionChange([...selectedSubscriptions, subId]);
    }
  };
  const toggleAll = () => {
    const transferableIds = searchResults.filter((s) => s.isTransferable).map((s) => s.id);
    const allSelected = transferableIds.every((id) => selectedSubscriptions.includes(id));
    if (allSelected) {
      onSelectionChange(selectedSubscriptions.filter((id) => !transferableIds.includes(id)));
    } else {
      onSelectionChange([.../* @__PURE__ */ new Set([...selectedSubscriptions, ...transferableIds])]);
    }
  };
  const selectedFromResults = searchResults.filter(
    (s) => selectedSubscriptions.includes(s.id) && s.isTransferable
  );
  const totalSelectedValue = calculateTotalValue(selectedSubscriptions);
  const groupedResults = searchResults.reduce((acc, sub) => {
    if (!acc[sub.customerId]) {
      acc[sub.customerId] = {
        customerName: sub.customerName,
        customerId: sub.customerId,
        subscriptions: []
      };
    }
    acc[sub.customerId].subscriptions.push(sub);
    return acc;
  }, {});
  return /* @__PURE__ */ jsxRuntimeExports.jsxs(Stack$1, { gap: "md", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsxs(Group$2, { gap: "xs", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx(
        TextInput,
        {
          placeholder: "Search by customer name, subscription ID, or product name...",
          value: searchQuery,
          onChange: (e) => setSearchQuery(e.currentTarget.value),
          onKeyDown: handleKeyDown,
          leftSection: /* @__PURE__ */ jsxRuntimeExports.jsx(Search, { size: 14 }),
          rightSection: searchQuery && /* @__PURE__ */ jsxRuntimeExports.jsx(ActionIcon$1, { size: "xs", variant: "subtle", onClick: clearSearch, children: /* @__PURE__ */ jsxRuntimeExports.jsx(X, { size: 12 }) }),
          style: { flex: 1 }
        }
      ),
      /* @__PURE__ */ jsxRuntimeExports.jsx(
        Button$1,
        {
          onClick: handleSearch,
          loading: isSearching,
          disabled: !searchQuery.trim(),
          children: "Search"
        }
      )
    ] }),
    isSearching && /* @__PURE__ */ jsxRuntimeExports.jsx(Center$1, { py: "xl", children: /* @__PURE__ */ jsxRuntimeExports.jsx(Loader$1, { size: "sm" }) }),
    !isSearching && hasSearched && searchResults.length === 0 && /* @__PURE__ */ jsxRuntimeExports.jsx(Alert$1, { icon: /* @__PURE__ */ jsxRuntimeExports.jsx(AlertCircle, { size: 16 }), color: "gray", variant: "light", children: /* @__PURE__ */ jsxRuntimeExports.jsxs(Text$2, { size: "sm", children: [
      'No subscriptions found matching "',
      searchQuery,
      '". Try a different search term.'
    ] }) }),
    !isSearching && searchResults.length > 0 && /* @__PURE__ */ jsxRuntimeExports.jsxs(Stack$1, { gap: "md", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs(Group$2, { justify: "space-between", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs(Text$2, { size: "sm", c: "dimmed", children: [
          "Found ",
          /* @__PURE__ */ jsxRuntimeExports.jsx("strong", { children: searchResults.length }),
          " subscription",
          searchResults.length !== 1 ? "s" : "",
          " across",
          " ",
          /* @__PURE__ */ jsxRuntimeExports.jsx("strong", { children: Object.keys(groupedResults).length }),
          " customer",
          Object.keys(groupedResults).length !== 1 ? "s" : ""
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(
          Button$1,
          {
            variant: "subtle",
            size: "xs",
            onClick: toggleAll,
            children: searchResults.filter((s) => s.isTransferable).every((s) => selectedSubscriptions.includes(s.id)) ? "Deselect All" : "Select All Eligible"
          }
        )
      ] }),
      Object.values(groupedResults).map((group) => /* @__PURE__ */ jsxRuntimeExports.jsxs(Card$1, { withBorder: true, padding: "xs", radius: "md", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs(Group$2, { gap: "xs", mb: "xs", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(ThemeIcon$1, { size: "sm", color: "blue", variant: "light", children: /* @__PURE__ */ jsxRuntimeExports.jsx(Building2, { size: 12 }) }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(Text$2, { size: "sm", fw: 600, children: group.customerName }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs(Badge$2, { size: "xs", variant: "light", color: "gray", children: [
            group.subscriptions.length,
            " subscription",
            group.subscriptions.length !== 1 ? "s" : ""
          ] })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs(Table$1, { striped: true, highlightOnHover: true, withTableBorder: true, children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(Table$1.Thead, { children: /* @__PURE__ */ jsxRuntimeExports.jsxs(Table$1.Tr, { children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(Table$1.Th, { style: { width: 40 } }),
            /* @__PURE__ */ jsxRuntimeExports.jsx(Table$1.Th, { children: "Product" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx(Table$1.Th, { children: "Subscription ID" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx(Table$1.Th, { children: "Qty" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx(Table$1.Th, { children: "Term" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx(Table$1.Th, { children: "Est. Value/mo" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx(Table$1.Th, { children: "Eligible" })
          ] }) }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(Table$1.Tbody, { children: group.subscriptions.map((sub) => /* @__PURE__ */ jsxRuntimeExports.jsxs(
            Table$1.Tr,
            {
              style: {
                opacity: sub.isTransferable ? 1 : 0.6,
                backgroundColor: selectedSubscriptions.includes(sub.id) ? "var(--mantine-color-teal-0)" : void 0
              },
              children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx(Table$1.Td, { children: /* @__PURE__ */ jsxRuntimeExports.jsx(
                  Checkbox,
                  {
                    checked: selectedSubscriptions.includes(sub.id),
                    onChange: () => toggleSubscription(sub.id),
                    disabled: !sub.isTransferable
                  }
                ) }),
                /* @__PURE__ */ jsxRuntimeExports.jsxs(Table$1.Td, { children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx(Text$2, { size: "sm", fw: 500, children: sub.productName }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx(Text$2, { size: "xs", c: "dimmed", children: sub.skuName })
                ] }),
                /* @__PURE__ */ jsxRuntimeExports.jsx(Table$1.Td, { children: /* @__PURE__ */ jsxRuntimeExports.jsx(Tooltip$1, { label: sub.microsoftSubscriptionId, children: /* @__PURE__ */ jsxRuntimeExports.jsxs(Text$2, { size: "xs", ff: "monospace", c: "dimmed", children: [
                  sub.microsoftSubscriptionId.slice(0, 8),
                  "..."
                ] }) }) }),
                /* @__PURE__ */ jsxRuntimeExports.jsx(Table$1.Td, { children: sub.quantity }),
                /* @__PURE__ */ jsxRuntimeExports.jsx(Table$1.Td, { children: formatTermDuration(sub.termDuration) }),
                /* @__PURE__ */ jsxRuntimeExports.jsxs(Table$1.Td, { children: [
                  "~",
                  formatCurrency(sub.monthlyValue)
                ] }),
                /* @__PURE__ */ jsxRuntimeExports.jsx(Table$1.Td, { children: sub.isTransferable ? /* @__PURE__ */ jsxRuntimeExports.jsx(Badge$2, { size: "xs", color: "green", variant: "light", children: "Yes" }) : /* @__PURE__ */ jsxRuntimeExports.jsx(Tooltip$1, { label: sub.ineligibilityReason, children: /* @__PURE__ */ jsxRuntimeExports.jsx(Badge$2, { size: "xs", color: "red", variant: "light", children: "No" }) }) })
              ]
            },
            sub.id
          )) })
        ] })
      ] }, group.customerId)),
      selectedSubscriptions.length > 0 && /* @__PURE__ */ jsxRuntimeExports.jsx(Card$1, { withBorder: true, bg: "teal.0", padding: "sm", radius: "md", children: /* @__PURE__ */ jsxRuntimeExports.jsxs(Group$2, { justify: "space-between", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs(Stack$1, { gap: 2, children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs(Text$2, { size: "sm", fw: 500, children: [
            selectedFromResults.length,
            " subscription",
            selectedFromResults.length !== 1 ? "s" : "",
            " selected"
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs(Text$2, { size: "xs", c: "dimmed", children: [
            "Est. total: ~",
            formatCurrency(totalSelectedValue),
            "/mo"
          ] })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(Button$1, { onClick: onInitiateTransfer, children: "Initiate Transfer" })
      ] }) })
    ] })
  ] });
}

const {useState} = await importShared('react');

const {Paper: Paper$1,Title,Group: Group$1,Button,Card,Text: Text$1,Accordion,Table,ThemeIcon,ActionIcon,Tooltip,Badge: Badge$1,Divider} = await importShared('@mantine/core');
function P2PTransfersPanel(_props) {
  const {
    incomingPending,
    outgoingPending,
    completedTransfers,
    failedTransfers,
    summary,
    loading: loadingTransfers,
    refresh: refreshTransfers,
    accept,
    reject,
    cancel
  } = useTransfers();
  const [isSyncing, setIsSyncing] = useState(false);
  const [createModalOpen, setCreateModalOpen] = useState(false);
  const [reviewModalOpen, setReviewModalOpen] = useState(false);
  const [detailsModalOpen, setDetailsModalOpen] = useState(false);
  const [selectedTransfer, setSelectedTransfer] = useState(null);
  const [selectedSubs, setSelectedSubs] = useState([]);
  const handleSync = async () => {
    setIsSyncing(true);
    notifications.show({
      id: "p2p-sync",
      title: "Syncing",
      message: "Syncing P2P transfer data from Microsoft Partner Centre...",
      color: "blue",
      loading: true,
      autoClose: false
    });
    try {
      await refreshTransfers();
      notifications.update({
        id: "p2p-sync",
        title: "Sync Complete",
        message: "All transfer data is up to date.",
        color: "green",
        loading: false,
        autoClose: 3e3
      });
    } catch {
      notifications.update({
        id: "p2p-sync",
        title: "Sync Failed",
        message: "Failed to sync transfer data. Please try again.",
        color: "red",
        loading: false,
        autoClose: 5e3
      });
    } finally {
      setIsSyncing(false);
    }
  };
  const handleViewDetails = (transfer) => {
    setSelectedTransfer(transfer);
    setDetailsModalOpen(true);
  };
  const handleReview = (transfer) => {
    setSelectedTransfer(transfer);
    setReviewModalOpen(true);
  };
  const handleAccept = async () => {
    if (!selectedTransfer) return;
    notifications.show({
      id: "accept-transfer",
      title: "Processing",
      message: "Accepting transfer request...",
      color: "blue",
      loading: true,
      autoClose: false
    });
    try {
      await accept(selectedTransfer.id);
      notifications.update({
        id: "accept-transfer",
        title: "Transfer Accepted",
        message: "The transfer is being processed by Microsoft.",
        color: "green",
        loading: false,
        autoClose: 5e3
      });
      setReviewModalOpen(false);
      setSelectedTransfer(null);
    } catch {
      notifications.update({
        id: "accept-transfer",
        title: "Failed",
        message: "Failed to accept transfer. Please try again.",
        color: "red",
        loading: false,
        autoClose: 5e3
      });
    }
  };
  const handleReject = async (reason) => {
    if (!selectedTransfer) return;
    try {
      await reject(selectedTransfer.id, reason);
      notifications.show({
        title: "Transfer Rejected",
        message: "The transfer request has been rejected.",
        color: "orange"
      });
      setReviewModalOpen(false);
      setSelectedTransfer(null);
    } catch {
      notifications.show({
        title: "Failed",
        message: "Failed to reject transfer. Please try again.",
        color: "red"
      });
    }
  };
  const handleCancel = async (transferId) => {
    try {
      await cancel(transferId);
      notifications.show({
        title: "Transfer Cancelled",
        message: "The transfer request has been cancelled.",
        color: "gray"
      });
    } catch {
      notifications.show({
        title: "Failed",
        message: "Failed to cancel transfer. Please try again.",
        color: "red"
      });
    }
  };
  const handleOpenCreate = () => {
    setCreateModalOpen(true);
  };
  const handleInitiateTransfer = () => {
    setCreateModalOpen(true);
  };
  if (loadingTransfers) {
    return /* @__PURE__ */ jsxRuntimeExports.jsx(LoadingState, { message: "Loading P2P transfers..." });
  }
  const renderTransferRow = (transfer) => {
    const daysRemaining = getDaysUntilExpiration(transfer.expirationDate);
    const isUrgent = daysRemaining <= 7 && transfer.status === "Pending";
    const partnerName = transfer.direction === "Incoming" ? transfer.sourcePartner.name : transfer.targetPartner.name;
    return /* @__PURE__ */ jsxRuntimeExports.jsxs(Table.Tr, { style: { backgroundColor: isUrgent ? "var(--mantine-color-orange-0)" : void 0 }, children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx(Table.Td, { children: /* @__PURE__ */ jsxRuntimeExports.jsxs(Group$1, { gap: "xs", children: [
        transfer.direction === "Incoming" ? /* @__PURE__ */ jsxRuntimeExports.jsx(ThemeIcon, { size: "sm", color: "blue", variant: "light", children: /* @__PURE__ */ jsxRuntimeExports.jsx(ArrowDownLeft, { size: 12 }) }) : /* @__PURE__ */ jsxRuntimeExports.jsx(ThemeIcon, { size: "sm", color: "teal", variant: "light", children: /* @__PURE__ */ jsxRuntimeExports.jsx(ArrowUpRight, { size: 12 }) }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(Text$1, { size: "sm", children: transfer.direction })
      ] }) }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(Table.Td, { children: /* @__PURE__ */ jsxRuntimeExports.jsx(Text$1, { size: "sm", fw: 500, children: partnerName }) }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(Table.Td, { children: /* @__PURE__ */ jsxRuntimeExports.jsx(Text$1, { size: "sm", children: transfer.lineItems.length }) }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(Table.Td, { children: /* @__PURE__ */ jsxRuntimeExports.jsxs(Text$1, { size: "sm", children: [
        "~",
        formatCurrency(transfer.totalMonthlyValue)
      ] }) }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(Table.Td, { children: /* @__PURE__ */ jsxRuntimeExports.jsx(TransferStatusBadge, { status: transfer.status, size: "xs" }) }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(Table.Td, { children: /* @__PURE__ */ jsxRuntimeExports.jsxs(Group$1, { gap: "xs", children: [
        isUrgent && /* @__PURE__ */ jsxRuntimeExports.jsx(Tooltip, { label: `Expires in ${daysRemaining} days`, children: /* @__PURE__ */ jsxRuntimeExports.jsx(AlertTriangle, { size: 14, className: "text-orange-500" }) }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(Text$1, { size: "xs", c: "dimmed", children: transfer.status === "Pending" ? formatDate(transfer.expirationDate) : formatDate(transfer.lastModifiedDate) })
      ] }) }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(Table.Td, { children: /* @__PURE__ */ jsxRuntimeExports.jsxs(Group$1, { gap: "xs", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(Tooltip, { label: "View Details", children: /* @__PURE__ */ jsxRuntimeExports.jsx(ActionIcon, { variant: "subtle", size: "sm", onClick: () => handleViewDetails(transfer), children: /* @__PURE__ */ jsxRuntimeExports.jsx(Eye, { size: 14 }) }) }),
        transfer.status === "Pending" && transfer.direction === "Incoming" && /* @__PURE__ */ jsxRuntimeExports.jsx(jsxRuntimeExports.Fragment, { children: /* @__PURE__ */ jsxRuntimeExports.jsx(Tooltip, { label: "Review & Accept", children: /* @__PURE__ */ jsxRuntimeExports.jsx(ActionIcon, { variant: "subtle", size: "sm", color: "green", onClick: () => handleReview(transfer), children: /* @__PURE__ */ jsxRuntimeExports.jsx(Check, { size: 14 }) }) }) }),
        transfer.status === "Pending" && transfer.direction === "Outgoing" && /* @__PURE__ */ jsxRuntimeExports.jsx(Tooltip, { label: "Cancel", children: /* @__PURE__ */ jsxRuntimeExports.jsx(ActionIcon, { variant: "subtle", size: "sm", color: "red", onClick: () => handleCancel(transfer.id), children: /* @__PURE__ */ jsxRuntimeExports.jsx(X, { size: 14 }) }) })
      ] }) })
    ] }, transfer.id);
  };
  return /* @__PURE__ */ jsxRuntimeExports.jsxs(Paper$1, { shadow: "xs", radius: "md", withBorder: true, p: "md", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsxs(Group$1, { justify: "space-between", mb: "md", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs(Group$1, { gap: "sm", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(Title, { order: 4, children: "P2P Subscription Transfers" }),
        summary.incomingPending > 0 && /* @__PURE__ */ jsxRuntimeExports.jsx(Badge$1, { color: "red", size: "lg", circle: true, children: summary.incomingPending })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs(Group$1, { gap: "xs", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(
          Button,
          {
            size: "xs",
            variant: "light",
            leftSection: /* @__PURE__ */ jsxRuntimeExports.jsx(RefreshCw, { size: 14, className: isSyncing ? "animate-spin" : "" }),
            onClick: handleSync,
            loading: isSyncing,
            children: "Sync"
          }
        ),
        /* @__PURE__ */ jsxRuntimeExports.jsx(
          Button,
          {
            size: "xs",
            leftSection: /* @__PURE__ */ jsxRuntimeExports.jsx(Plus, { size: 14 }),
            onClick: handleOpenCreate,
            children: "New Transfer"
          }
        )
      ] })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { style: { display: "grid", gridTemplateColumns: "repeat(4, 1fr)", gap: "12px", marginBottom: "16px" }, children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs(Card, { shadow: "xs", padding: "sm", radius: "md", withBorder: true, children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs(Group$1, { gap: "xs", mb: 4, children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(ThemeIcon, { size: "sm", color: "blue", variant: "light", children: /* @__PURE__ */ jsxRuntimeExports.jsx(ArrowDownLeft, { size: 12 }) }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(Text$1, { size: "xs", c: "dimmed", tt: "uppercase", fw: 600, children: "Incoming" })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(Text$1, { size: "xl", fw: 700, children: summary.incomingPending }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(Text$1, { size: "xs", c: "dimmed", children: "pending review" })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs(Card, { shadow: "xs", padding: "sm", radius: "md", withBorder: true, children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs(Group$1, { gap: "xs", mb: 4, children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(ThemeIcon, { size: "sm", color: "teal", variant: "light", children: /* @__PURE__ */ jsxRuntimeExports.jsx(ArrowUpRight, { size: 12 }) }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(Text$1, { size: "xs", c: "dimmed", tt: "uppercase", fw: 600, children: "Outgoing" })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(Text$1, { size: "xl", fw: 700, children: summary.outgoingPending }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(Text$1, { size: "xs", c: "dimmed", children: "awaiting response" })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs(Card, { shadow: "xs", padding: "sm", radius: "md", withBorder: true, children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs(Group$1, { gap: "xs", mb: 4, children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(ThemeIcon, { size: "sm", color: "green", variant: "light", children: /* @__PURE__ */ jsxRuntimeExports.jsx(CheckCircle, { size: 12 }) }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(Text$1, { size: "xs", c: "dimmed", tt: "uppercase", fw: 600, children: "Completed" })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(Text$1, { size: "xl", fw: 700, children: summary.completedLast90Days }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(Text$1, { size: "xs", c: "dimmed", children: "last 90 days" })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs(Card, { shadow: "xs", padding: "sm", radius: "md", withBorder: true, children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs(Group$1, { gap: "xs", mb: 4, children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(ThemeIcon, { size: "sm", color: "red", variant: "light", children: /* @__PURE__ */ jsxRuntimeExports.jsx(XCircle, { size: 12 }) }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(Text$1, { size: "xs", c: "dimmed", tt: "uppercase", fw: 600, children: "Failed" })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(Text$1, { size: "xl", fw: 700, children: summary.failedLast90Days }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(Text$1, { size: "xs", c: "dimmed", children: "last 90 days" })
      ] })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsx(Divider, { my: "md" }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs(Accordion, { variant: "separated", radius: "md", multiple: true, defaultValue: ["subscriptions", "active"], children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs(Accordion.Item, { value: "subscriptions", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(Accordion.Control, { children: /* @__PURE__ */ jsxRuntimeExports.jsxs(Group$1, { gap: "xs", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(Search, { size: 16 }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(Text$1, { fw: 500, children: "Find Subscriptions for Transfer" })
        ] }) }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(Accordion.Panel, { children: /* @__PURE__ */ jsxRuntimeExports.jsx(
          SubscriptionSearch,
          {
            selectedSubscriptions: selectedSubs,
            onSelectionChange: setSelectedSubs,
            onInitiateTransfer: handleInitiateTransfer
          }
        ) })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs(Accordion.Item, { value: "active", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(Accordion.Control, { children: /* @__PURE__ */ jsxRuntimeExports.jsxs(Group$1, { gap: "xs", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(Text$1, { fw: 500, children: "Active Transfers" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(Badge$1, { size: "sm", variant: "light", color: "blue", children: incomingPending.length + outgoingPending.length })
        ] }) }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(Accordion.Panel, { children: incomingPending.length + outgoingPending.length > 0 ? /* @__PURE__ */ jsxRuntimeExports.jsxs(Table, { striped: true, highlightOnHover: true, children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(Table.Thead, { children: /* @__PURE__ */ jsxRuntimeExports.jsxs(Table.Tr, { children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(Table.Th, { children: "Direction" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx(Table.Th, { children: "Partner" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx(Table.Th, { children: "Items" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx(Table.Th, { children: "Est. Value" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx(Table.Th, { children: "Status" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx(Table.Th, { children: "Expires" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx(Table.Th, { children: "Actions" })
          ] }) }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(Table.Tbody, { children: [...incomingPending, ...outgoingPending].map(renderTransferRow) })
        ] }) : /* @__PURE__ */ jsxRuntimeExports.jsx(Text$1, { size: "sm", c: "dimmed", ta: "center", py: "xl", children: "No active transfers" }) })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs(Accordion.Item, { value: "history", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(Accordion.Control, { children: /* @__PURE__ */ jsxRuntimeExports.jsxs(Group$1, { gap: "xs", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(Text$1, { fw: 500, children: "Transfer History" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(Badge$1, { size: "sm", variant: "light", color: "gray", children: completedTransfers.length + failedTransfers.length })
        ] }) }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(Accordion.Panel, { children: completedTransfers.length + failedTransfers.length > 0 ? /* @__PURE__ */ jsxRuntimeExports.jsxs(Table, { striped: true, highlightOnHover: true, children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(Table.Thead, { children: /* @__PURE__ */ jsxRuntimeExports.jsxs(Table.Tr, { children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(Table.Th, { children: "Direction" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx(Table.Th, { children: "Partner" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx(Table.Th, { children: "Items" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx(Table.Th, { children: "Est. Value" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx(Table.Th, { children: "Status" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx(Table.Th, { children: "Date" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx(Table.Th, { children: "Actions" })
          ] }) }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(Table.Tbody, { children: [...completedTransfers, ...failedTransfers].map(renderTransferRow) })
        ] }) : /* @__PURE__ */ jsxRuntimeExports.jsx(Text$1, { size: "sm", c: "dimmed", ta: "center", py: "xl", children: "No transfer history" }) })
      ] })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsx(
      CreateTransferModal,
      {
        open: createModalOpen,
        onClose: () => {
          setCreateModalOpen(false);
          setSelectedSubs([]);
        },
        selectedSubscriptionIds: selectedSubs
      }
    ),
    /* @__PURE__ */ jsxRuntimeExports.jsx(
      ReviewTransferModal,
      {
        open: reviewModalOpen,
        onClose: () => {
          setReviewModalOpen(false);
          setSelectedTransfer(null);
        },
        transfer: selectedTransfer,
        onAccept: handleAccept,
        onReject: handleReject
      }
    ),
    /* @__PURE__ */ jsxRuntimeExports.jsx(
      TransferDetailsModal,
      {
        open: detailsModalOpen,
        onClose: () => {
          setDetailsModalOpen(false);
          setSelectedTransfer(null);
        },
        transfer: selectedTransfer
      }
    )
  ] });
}

const {Container,Alert,Center,Loader,Stack,Paper,Group,Text,Badge} = await importShared('@mantine/core');
function App() {
  const { company, user, loading, error, isMarketplaceManager } = useExtensionContext();
  if (loading) {
    return /* @__PURE__ */ jsxRuntimeExports.jsx(Center, { py: "xl", style: { minHeight: 300 }, children: /* @__PURE__ */ jsxRuntimeExports.jsxs(Stack, { align: "center", gap: "md", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx(Loader, { size: "lg" }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(Text, { c: "dimmed", children: "Loading P2P Transfers Extension..." })
    ] }) });
  }
  if (error) {
    return /* @__PURE__ */ jsxRuntimeExports.jsx(Container, { size: "md", py: "xl", children: /* @__PURE__ */ jsxRuntimeExports.jsx(
      Alert,
      {
        icon: /* @__PURE__ */ jsxRuntimeExports.jsx(AlertCircle, { size: 16 }),
        title: "Error loading extension",
        color: "red",
        children: error.message
      }
    ) });
  }
  if (!company) {
    return /* @__PURE__ */ jsxRuntimeExports.jsx(Container, { size: "md", py: "xl", children: /* @__PURE__ */ jsxRuntimeExports.jsx(
      Alert,
      {
        icon: /* @__PURE__ */ jsxRuntimeExports.jsx(AlertCircle, { size: 16 }),
        title: "Company context required",
        color: "yellow",
        children: "This extension must be viewed within a company context."
      }
    ) });
  }
  return /* @__PURE__ */ jsxRuntimeExports.jsxs(Container, { size: "xl", py: "md", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx(DemoBanner, {}),
    /* @__PURE__ */ jsxRuntimeExports.jsx(Paper, { withBorder: true, p: "xs", mb: "md", radius: "md", bg: "gray.0", children: /* @__PURE__ */ jsxRuntimeExports.jsxs(Group, { justify: "space-between", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs(Group, { gap: "lg", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs(Group, { gap: "xs", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(Building2, { size: 14, className: "text-gray-500" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(Text, { size: "sm", fw: 500, children: company.name }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs(Text, { size: "xs", c: "dimmed", ff: "monospace", children: [
            company.microsoftTenantId?.slice(0, 8),
            "..."
          ] })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs(Group, { gap: "xs", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(User, { size: 14, className: "text-gray-500" }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs(Text, { size: "sm", children: [
            user?.firstName,
            " ",
            user?.lastName
          ] })
        ] })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(Group, { gap: "xs", children: isMarketplaceManager && /* @__PURE__ */ jsxRuntimeExports.jsx(Badge, { color: "blue", variant: "light", size: "sm", children: "Marketplace Manager" }) })
    ] }) }),
    /* @__PURE__ */ jsxRuntimeExports.jsx(P2PTransfersPanel, { companyId: company.id })
  ] });
}

export { ExtensionProvider as E, P2PProvider as P, notifications as a, mockSubscriptions as b, App as default, hideNotification as h, mockTransferRequests as m, notificationsStore as n, useNotifications as u };
//# sourceMappingURL=__federation_expose_P2PExtension-DlzsM6A8.js.map
