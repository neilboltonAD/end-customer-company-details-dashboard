export { i as default } from './index-Dm_EQZZA.js';
//# sourceMappingURL=__federation_shared_react-BCcI129A.js.map
